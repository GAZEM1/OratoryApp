# Oratory / Magick Practice Desk

A focused daily practice app for oratory (speech), readings, structured paths, exercises, and a magical diary/journal.

## Features
- **Library** — curated readings (method, theory, diary technique)
- **Paths** — guided curricula and lesson sequences
- **Practice** — timed exercises (speech, breath, ritual, attention)
- **Journal** — quick daily notes tied to the work
- **Streak & progress** tracking on device

Built with TanStack Start / React / Vite / Tailwind.

## Run locally

```bash
npm install
npm run dev
```

App runs on http://localhost:8080

## Notes
This is the source from the Grok workspace build. Some auth/preview scaffolding remains from the original builder environment and can be simplified later if desired.
