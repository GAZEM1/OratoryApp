export type Sephirah = {
  id: string;
  n: number;
  name: string;
  meaning: string;
  x: number;
  y: number;
  planet: string;
  idea: string;
  study: string;
};

export type TreePath = {
  n: number;
  letter: string;
  hebrew: string;
  card: string;
  from: string;
  to: string;
  note: string;
};

export const sephiroth: Sephirah[] = [
  {
    id: "kether",
    n: 1,
    name: "Kether",
    meaning: "Crown",
    x: 160,
    y: 40,
    planet: "Primum Mobile, later linked with Neptune",
    idea: "Unity before anything splits into two.",
    study: "Sit with one sensation — breath at the nostril — and refuse to narrate it. Kether, in this map, is the moment prior to a story.",
  },
  {
    id: "chokmah",
    n: 2,
    name: "Chokmah",
    meaning: "Wisdom",
    x: 258,
    y: 108,
    planet: "The zodiac, later Uranus",
    idea: "The first outward flash. Force without a container yet.",
    study: "Write a want in six words, fast, before you edit it into something polite.",
  },
  {
    id: "binah",
    n: 3,
    name: "Binah",
    meaning: "Understanding",
    x: 62,
    y: 108,
    planet: "Saturn",
    idea: "Limit, form, time, the womb that gives the flash an edge.",
    study: "Take yesterday's want and name the constraint that would make it real: an hour, a tool, a boundary.",
  },
  {
    id: "chesed",
    n: 4,
    name: "Chesed",
    meaning: "Mercy",
    x: 258,
    y: 214,
    planet: "Jupiter",
    idea: "Expansion, generosity, the lawful building of more.",
    study: "Give something concrete away today — time, a note, a meal — and write what it cost.",
  },
  {
    id: "geburah",
    n: 5,
    name: "Geburah",
    meaning: "Severity",
    x: 62,
    y: 214,
    planet: "Mars",
    idea: "Strength as the power to cut, stop, and defend a form.",
    study: "Name one practice you will not do, and the reason. Severity without a reason is just temper.",
  },
  {
    id: "tiphareth",
    n: 6,
    name: "Tiphareth",
    meaning: "Beauty",
    x: 160,
    y: 262,
    planet: "The Sun",
    idea: "The center that holds mercy and severity in one working heart.",
    study: "After any exercise, ask: was this balanced enough to repeat tomorrow? Beauty here means coherence, not prettiness.",
  },
  {
    id: "netzach",
    n: 7,
    name: "Netzach",
    meaning: "Victory",
    x: 258,
    y: 352,
    planet: "Venus",
    idea: "Desire, rhythm, art, the green persistence of wanting.",
    study: "Make one unnecessary beautiful thing connected to the work: a cleaned altar corner, a careful page, a walked loop.",
  },
  {
    id: "hod",
    n: 8,
    name: "Hod",
    meaning: "Splendour",
    x: 62,
    y: 352,
    planet: "Mercury",
    idea: "Language, analysis, names, the mind that can say what happened.",
    study: "Translate one feeling from practice into three plain sentences. If you cannot say it, you do not have it yet.",
  },
  {
    id: "yesod",
    n: 9,
    name: "Yesod",
    meaning: "Foundation",
    x: 160,
    y: 430,
    planet: "The Moon",
    idea: "Imagination, dream, the image-store that feeds the body.",
    study: "Before sleep, write one image you intend to remember. In the morning, write what actually came.",
  },
  {
    id: "malkuth",
    n: 10,
    name: "Malkuth",
    meaning: "Kingdom",
    x: 160,
    y: 516,
    planet: "Earth",
    idea: "The body, the room, the rent, the result you can point at.",
    study: "End every working by touching the floor, naming the date, and doing one ordinary next thing. Magick that cannot land is a mood.",
  },
];

/** Hermetic Golden Dawn paths on the Kircher tree. Letter–card pairings follow the traditional GD order; Crowley later swapped Heh and Tzaddi. */
export const treePaths: TreePath[] = [
  { n: 11, letter: "Aleph", hebrew: "א", card: "The Fool", from: "kether", to: "chokmah", note: "Air. The leap from unity into the first distinction." },
  { n: 12, letter: "Beth", hebrew: "ב", card: "The Magician", from: "kether", to: "binah", note: "Mercury. Attention that can aim." },
  { n: 13, letter: "Gimel", hebrew: "ג", card: "The High Priestess", from: "kether", to: "tiphareth", note: "The Moon, on this path. The long road across the abyss, passing Daath." },
  { n: 14, letter: "Daleth", hebrew: "ד", card: "The Empress", from: "chokmah", to: "binah", note: "Venus. The door between force and form." },
  { n: 15, letter: "Heh", hebrew: "ה", card: "The Emperor", from: "chokmah", to: "tiphareth", note: "Aries. Ordering fire. Crowley reassigned this letter to The Star." },
  { n: 16, letter: "Vav", hebrew: "ו", card: "The Hierophant", from: "chokmah", to: "chesed", note: "Taurus. Teaching, transmission, the nail that joins." },
  { n: 17, letter: "Zayin", hebrew: "ז", card: "The Lovers", from: "binah", to: "tiphareth", note: "Gemini. A choice that is also a sword." },
  { n: 18, letter: "Cheth", hebrew: "ח", card: "The Chariot", from: "binah", to: "geburah", note: "Cancer. A body that can carry an intention through noise." },
  { n: 19, letter: "Teth", hebrew: "ט", card: "Strength", from: "chesed", to: "geburah", note: "Leo. Mercy and severity held by the same hands." },
  { n: 20, letter: "Yod", hebrew: "י", card: "The Hermit", from: "chesed", to: "tiphareth", note: "Virgo. A small light carried on purpose." },
  { n: 21, letter: "Kaph", hebrew: "כ", card: "The Wheel", from: "chesed", to: "netzach", note: "Jupiter. Cycles, luck, the turn of conditions." },
  { n: 22, letter: "Lamed", hebrew: "ל", card: "Justice", from: "geburah", to: "tiphareth", note: "Libra. Adjustment. The ox-goad that corrects a course." },
  { n: 23, letter: "Mem", hebrew: "מ", card: "The Hanged Man", from: "geburah", to: "hod", note: "Water. Suspension, the view from upside down." },
  { n: 24, letter: "Nun", hebrew: "נ", card: "Death", from: "tiphareth", to: "netzach", note: "Scorpio. What has to rot so something else can move." },
  { n: 25, letter: "Samekh", hebrew: "ס", card: "Temperance", from: "tiphareth", to: "yesod", note: "Sagittarius. Mixing, the arrow, the tested middle." },
  { n: 26, letter: "Ayin", hebrew: "ע", card: "The Devil", from: "tiphareth", to: "hod", note: "Capricorn. The chain you can see is a chain you can work." },
  { n: 27, letter: "Peh", hebrew: "פ", card: "The Tower", from: "netzach", to: "hod", note: "Mars. Speech and structure struck open." },
  { n: 28, letter: "Tzaddi", hebrew: "צ", card: "The Star", from: "netzach", to: "yesod", note: "Aquarius. Hope after the strike. Crowley reassigned this letter to The Emperor." },
  { n: 29, letter: "Qoph", hebrew: "ק", card: "The Moon", from: "netzach", to: "malkuth", note: "Pisces. The long instinctive road down into the body." },
  { n: 30, letter: "Resh", hebrew: "ר", card: "The Sun", from: "hod", to: "yesod", note: "The Sun. Intellect warming the image-world." },
  { n: 31, letter: "Shin", hebrew: "ש", card: "Judgement", from: "hod", to: "malkuth", note: "Fire. A call that wakes what was lying down." },
  { n: 32, letter: "Tav", hebrew: "ת", card: "The World", from: "yesod", to: "malkuth", note: "Saturn, and the elements together. The path into the kingdom you can touch." },
];

export const pillars = [
  {
    name: "Severity",
    side: "Left as you face the diagram",
    sephiroth: "Binah, Geburah, Hod",
    text: "Form, boundary, analysis. The pillar that stops a thing from spilling into everything.",
  },
  {
    name: "Mildness",
    side: "The middle",
    sephiroth: "Kether, Tiphareth, Yesod, Malkuth",
    text: "The line of equilibrium. Daath sits on this pillar between Kether and Tiphareth and is not counted as one of the ten.",
  },
  {
    name: "Mercy",
    side: "Right as you face the diagram",
    sephiroth: "Chokmah, Chesed, Netzach",
    text: "Force, expansion, desire. The pillar that starts more than it finishes.",
  },
];

export function sephirahById(id: string) {
  return sephiroth.find((item) => item.id === id);
}
