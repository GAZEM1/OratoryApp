export type StepItem = {
  title: string;
  detail: string;
};

export type Exercise = {
  id: string;
  title: string;
  minutes: number;
  kicker: string;
  summary: string;
  kind: "breath" | "timer" | "steps" | "sigil" | "intent" | "cards" | "diary";
  lessonId?: string;
  steps?: StepItem[];
};

export const exercises: Exercise[] = [
  {
    id: "fourfold-breath",
    title: "Fourfold breath",
    minutes: 8,
    kicker: "Inhibitory",
    summary: "A square breath: in, hold, out, hold. Eight rounds, then two minutes with no count.",
    kind: "breath",
    lessonId: "breath-and-posture",
  },
  {
    id: "five-senses",
    title: "Five senses, then the room",
    minutes: 6,
    kicker: "Ground",
    summary: "Name what the body is actually in, before you add a symbol to it.",
    kind: "steps",
    lessonId: "four-elements",
    steps: [
      {
        title: "Feet",
        detail: "Both feet on the floor. Say, quietly, where you are: the room, the building, the town. If you do not know the direction of east, decide which wall you will treat as east for this month and write that down.",
      },
      {
        title: "Five things you see",
        detail: "Name them plainly. Not omens. The crack in the cup counts. Do not interpret.",
      },
      {
        title: "Four things you feel",
        detail: "Cloth, temperature, the chair, a pain you usually talk over. Stay with each for one breath.",
      },
      {
        title: "Three sounds",
        detail: "Near, middle, far. Let the furthest one be the edge of the working space.",
      },
      {
        title: "Two smells, one taste",
        detail: "Even if the smell is only the room and the taste is only your mouth. Earth is this specific.",
      },
      {
        title: "One sentence",
        detail: "Say what you are here to study, in one sentence, present tense. Then stop. Write the sentence in the diary if it is worth keeping.",
      },
    ],
  },
  {
    id: "statement",
    title: "Statement of intent",
    minutes: 10,
    kicker: "Will",
    summary: "Hammer one sentence until it is present, positive, yours, and checkable.",
    kind: "intent",
    lessonId: "what-magick-is",
  },
  {
    id: "sigil-atelier",
    title: "Sigil bench",
    minutes: 20,
    kicker: "Chaos",
    summary: "Spare's letter method, then a monogram you draw with your own hand and put away.",
    kind: "sigil",
    lessonId: "sigil-method",
  },
  {
    id: "lbrp-rehearsal",
    title: "Pentagram ritual, rehearsed",
    minutes: 15,
    kicker: "Golden Dawn",
    summary: "Walk the lesser banishing score one station at a time. Cross, four quarters, archangels, cross.",
    kind: "steps",
    lessonId: "lbrp-study",
    steps: [
      {
        title: "Stand and face your east",
        detail: "A few even breaths. Say, if you need to hear it: this is a rehearsal of the Lesser Banishing Ritual of the Pentagram. You are learning a score, not collecting a mood.",
      },
      {
        title: "Qabalistic cross",
        detail: "Forehead: Ateh. Chest: Malkuth. Right shoulder: ve-Geburah. Left shoulder: ve-Gedulah. Hands clasped: le-Olam, amen. Feel each word finish before the next.",
      },
      {
        title: "East",
        detail: "Draw the banishing earth pentagram, large enough to step into. Start at the lower left point, up to the apex, down to the lower right, up to the upper left, across to the upper right, and back to the start. Point to the center. Vibrate Yod Heh Vav Heh, letter by letter.",
      },
      {
        title: "South",
        detail: "Turn to the south. The same pentagram. Vibrate Adonai. In the lodge this quarter is fire, and Michael stands here — at your right hand when you face east.",
      },
      {
        title: "West",
        detail: "The same pentagram. Vibrate Eheieh. Water, Gabriel, behind you when you face east.",
      },
      {
        title: "North",
        detail: "The same pentagram. Vibrate Agla. Earth, Auriel, at your left hand when you face east.",
      },
      {
        title: "The archangels",
        detail: "Face east again. Arms in a cross. Before me Raphael. Behind me Gabriel. At my right hand Michael. At my left hand Auriel. For about me flames the pentagram, and in the column shines the six-rayed star.",
      },
      {
        title: "Close",
        detail: "Repeat the Qabalistic cross. Feel the floor. Do not add a second ritual. Write what attention did: where you forgot a name, where you rushed, whether anything in the room seemed different. Nothing is a complete result.",
      },
    ],
  },
  {
    id: "sit-ten",
    title: "Ten-minute sit",
    minutes: 10,
    kicker: "Inhibitory",
    summary: "A plain sit. No count. When the bell goes, write before you speak.",
    kind: "timer",
    lessonId: "using-the-map",
  },
  {
    id: "tree-cards",
    title: "Correspondence cards",
    minutes: 8,
    kicker: "Memory",
    summary: "Sephiroth, a few paths, the quarters, and the names. Again, or known.",
    kind: "cards",
    lessonId: "ten-spheres",
  },
  {
    id: "evening-record",
    title: "Evening record",
    minutes: 10,
    kicker: "Diary",
    summary: "Condition of the body, what you did, what happened. The practice under everything else.",
    kind: "diary",
    lessonId: "the-record",
  },
];

export function findExercise(id: string) {
  return exercises.find((exercise) => exercise.id === id) ?? null;
}

const byWeekday = [
  "sit-ten",
  "evening-record",
  "lbrp-rehearsal",
  "tree-cards",
  "statement",
  "sigil-atelier",
  "fourfold-breath",
];

export function exerciseForDate(date = new Date()) {
  const id = byWeekday[date.getDay()];
  return findExercise(id) ?? exercises[0];
}
