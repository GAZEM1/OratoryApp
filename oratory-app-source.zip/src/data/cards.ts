export type StudyCard = {
  id: string;
  front: string;
  back: string;
  tag: string;
};

export const studyCards: StudyCard[] = [
  { id: "kether", tag: "Tree", front: "Kether", back: "Crown. Unity before division. Hermetic attribution: the Primum Mobile, later Neptune." },
  { id: "chokmah", tag: "Tree", front: "Chokmah", back: "Wisdom. The first outward force. Zodiac, later Uranus. Top of the pillar of mercy." },
  { id: "binah", tag: "Tree", front: "Binah", back: "Understanding. Form, limit, Saturn. Top of the pillar of severity." },
  { id: "chesed", tag: "Tree", front: "Chesed", back: "Mercy. Expansion and generosity. Jupiter." },
  { id: "geburah", tag: "Tree", front: "Geburah", back: "Severity. The power to cut and to hold a boundary. Mars." },
  { id: "tiphareth", tag: "Tree", front: "Tiphareth", back: "Beauty. The center of the tree, where the pillars are reconciled. The Sun." },
  { id: "netzach", tag: "Tree", front: "Netzach", back: "Victory. Desire, rhythm, art. Venus." },
  { id: "hod", tag: "Tree", front: "Hod", back: "Splendour. Language, names, analysis. Mercury." },
  { id: "yesod", tag: "Tree", front: "Yesod", back: "Foundation. Imagination, dream, the image-body. The Moon." },
  { id: "malkuth", tag: "Tree", front: "Malkuth", back: "Kingdom. The physical world and the body. Earth. If it does not land here, it is not finished." },
  { id: "daath", tag: "Tree", front: "What is Daath?", back: "Knowledge. Drawn on the middle pillar between Kether and Tiphareth, but not one of the ten sephiroth. A mark of the abyss, not a place you collect." },
  { id: "aleph", tag: "Paths", front: "Path 11, Aleph", back: "The Fool. Air. Joins Kether and Chokmah." },
  { id: "gimel", tag: "Paths", front: "Path 13, Gimel", back: "The High Priestess. Joins Kether and Tiphareth, crossing where Daath is marked." },
  { id: "tav", tag: "Paths", front: "Path 32, Tav", back: "The World. Joins Yesod and Malkuth. The last step into the kingdom." },
  { id: "east", tag: "Quarters", front: "Golden Dawn east", back: "Air. The archangel Raphael. You face this way to begin the Lesser Ritual of the Pentagram." },
  { id: "south", tag: "Quarters", front: "Golden Dawn south", back: "Fire. The archangel Michael. At your right hand when you face east." },
  { id: "west", tag: "Quarters", front: "Golden Dawn west", back: "Water. The archangel Gabriel. Behind you when you face east." },
  { id: "north", tag: "Quarters", front: "Golden Dawn north", back: "Earth. The archangel Auriel (Uriel). At your left hand when you face east." },
  { id: "yHVH", tag: "LBRP", front: "East, in the LBRP", back: "Draw the banishing earth pentagram and vibrate the Tetragrammaton, Yod Heh Vav Heh." },
  { id: "adonai", tag: "LBRP", front: "South, in the LBRP", back: "Banishing earth pentagram. Divine name: Adonai." },
  { id: "eheieh", tag: "LBRP", front: "West, in the LBRP", back: "Banishing earth pentagram. Divine name: Eheieh." },
  { id: "agla", tag: "LBRP", front: "North, in the LBRP", back: "Banishing earth pentagram. Divine name: Agla." },
  { id: "cross", tag: "LBRP", front: "Qabalistic cross, the words", back: "Forehead Ateh. Chest Malkuth. Right shoulder ve-Geburah. Left shoulder ve-Gedulah. Clasped hands: le-Olam, Amen." },
  { id: "sigil", tag: "Chaos", front: "Spare's letter method, in order", back: "Write the intent. Remove vowels and repeated letters. Combine what remains into a glyph. Charge it in gnosis. Then let the desire go." },
  { id: "gnosis", tag: "Chaos", front: "Two classical doors of gnosis", back: "Inhibitory: stillness, silence, trance, the mind emptied. Excitatory: breath, movement, chant, dance, until the ordinary narrator drops. This desk does not use drugs as a door." },
  { id: "models", tag: "Theory", front: "Name five models of magick", back: "Spirit. Energy. Psychological. Information. Meta — the chaos move of using whichever model does the work, and writing down which one you used." },
  { id: "will", tag: "Theory", front: "Crowley's one-sentence definition", back: "Magick is the science and art of causing change to occur in conformity with Will. From the introduction to Magick in Theory and Practice." },
  { id: "kybalion", tag: "Sources", front: "When was the Kybalion written?", back: "1908, by William Walker Atkinson under the mask 'Three Initiates'. It is a New Thought book, not an ancient Egyptian Hermetic text." },
  { id: "diary", tag: "Practice", front: "What does a magical diary record first?", back: "The date, and the condition of the body: sleep, food, health, mood. Then the practice. Then what actually happened, including nothing." },
];
