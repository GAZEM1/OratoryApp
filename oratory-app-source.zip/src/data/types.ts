export type Block =
  | { type: "p"; text: string }
  | { type: "h"; text: string }
  | { type: "quote"; text: string; cite?: string }
  | { type: "steps"; items: string[] }
  | { type: "note"; tone: "caution" | "source"; title?: string; text: string }
  | { type: "link"; href: string; label: string };

export type Lesson = {
  id: string;
  title: string;
  minutes: number;
  exerciseId?: string;
  readingId?: string;
  diagram?: "pentagram";
  blocks: Block[];
};

export type Path = {
  id: string;
  title: string;
  kicker: string;
  blurb: string;
  lessons: Lesson[];
};

export type Reading = {
  id: string;
  title: string;
  minutes: number;
  shelf: string;
  blocks: Block[];
};
