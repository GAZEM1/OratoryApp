import { create } from "zustand";
import { persist } from "zustand/middleware";

export type RecentKind = "lesson" | "reading" | "exercise";

export type RecentItem = {
  kind: RecentKind;
  id: string;
  at: number;
};

export type JournalEntry = {
  id: string;
  at: number;
  condition: string;
  body: string;
  practiceId?: string;
};

export type SavedSigil = {
  id: string;
  at: number;
  statement: string;
  letters: string;
  image: string;
};

export type CardMemory = {
  box: number;
  due: number;
};

type Persisted = {
  lessons: Record<string, number>;
  readings: Record<string, number>;
  exercises: Record<string, number>;
  journal: JournalEntry[];
  sigils: SavedSigil[];
  cards: Record<string, CardMemory>;
  streak: number;
  lastDay: string | null;
  recent: RecentItem[];
  intent: string;
  sigilStatement: string;
};

type DeskState = Persisted & {
  hydrated: boolean;
  setHydrated: (value: boolean) => void;
  markLesson: (id: string) => void;
  markReading: (id: string) => void;
  markExercise: (id: string) => void;
  remember: (kind: RecentKind, id: string) => void;
  addJournal: (entry: Omit<JournalEntry, "id" | "at"> & { at?: number }) => void;
  removeJournal: (id: string) => void;
  addSigil: (sigil: Omit<SavedSigil, "id" | "at">) => void;
  removeSigil: (id: string) => void;
  setIntent: (value: string) => void;
  setSigilStatement: (value: string) => void;
  gradeCard: (id: string, known: boolean) => void;
  clearDesk: () => void;
};

const empty: Persisted = {
  lessons: {},
  readings: {},
  exercises: {},
  journal: [],
  sigils: [],
  cards: {},
  streak: 0,
  lastDay: null,
  recent: [],
  intent: "",
  sigilStatement: "",
};

export function localDay(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function previousDay(date = new Date()) {
  const copy = new Date(date);
  copy.setDate(copy.getDate() - 1);
  return localDay(copy);
}

function withDay(state: Persisted) {
  const today = localDay();
  if (state.lastDay === today) {
    return { streak: Math.max(1, state.streak), lastDay: today };
  }
  const streak = state.lastDay === previousDay() ? state.streak + 1 : 1;
  return { streak, lastDay: today };
}

function rememberList(recent: RecentItem[], item: RecentItem) {
  return [item, ...recent.filter((entry) => !(entry.kind === item.kind && entry.id === item.id))].slice(
    0,
    12,
  );
}

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

export const useDesk = create<DeskState>()(
  persist(
    (set) => ({
      ...empty,
      hydrated: false,
      setHydrated: (value) => set({ hydrated: value }),
      markLesson: (id) =>
        set((state) => ({
          ...withDay(state),
          lessons: { ...state.lessons, [id]: Date.now() },
          recent: rememberList(state.recent, { kind: "lesson", id, at: Date.now() }),
        })),
      markReading: (id) =>
        set((state) => ({
          ...withDay(state),
          readings: { ...state.readings, [id]: Date.now() },
          recent: rememberList(state.recent, { kind: "reading", id, at: Date.now() }),
        })),
      markExercise: (id) =>
        set((state) => ({
          ...withDay(state),
          exercises: { ...state.exercises, [id]: Date.now() },
          recent: rememberList(state.recent, { kind: "exercise", id, at: Date.now() }),
        })),
      remember: (kind, id) =>
        set((state) => ({
          recent: rememberList(state.recent, { kind, id, at: Date.now() }),
        })),
      addJournal: (entry) =>
        set((state) => ({
          ...withDay(state),
          journal: [
            {
              id: uid(),
              at: entry.at ?? Date.now(),
              condition: entry.condition.trim(),
              body: entry.body.trim(),
              practiceId: entry.practiceId,
            },
            ...state.journal,
          ].slice(0, 200),
        })),
      removeJournal: (id) =>
        set((state) => ({ journal: state.journal.filter((entry) => entry.id !== id) })),
      addSigil: (sigil) =>
        set((state) => ({
          ...withDay(state),
          exercises: { ...state.exercises, "sigil-atelier": Date.now() },
          sigils: [
            { id: uid(), at: Date.now(), ...sigil },
            ...state.sigils,
          ].slice(0, 12),
          recent: rememberList(state.recent, {
            kind: "exercise",
            id: "sigil-atelier",
            at: Date.now(),
          }),
        })),
      removeSigil: (id) => set((state) => ({ sigils: state.sigils.filter((item) => item.id !== id) })),
      setIntent: (value) => set({ intent: value }),
      setSigilStatement: (value) => set({ sigilStatement: value }),
      gradeCard: (id, known) =>
        set((state) => {
          const current = state.cards[id] ?? { box: 0, due: 0 };
          const box = known ? Math.min(5, current.box + 1) : 0;
          const day = 86_400_000;
          const due = known ? Date.now() + box * day : Date.now() + 10 * 60_000;
          return {
            ...withDay(state),
            cards: { ...state.cards, [id]: { box, due } },
            exercises: { ...state.exercises, "tree-cards": Date.now() },
          };
        }),
      clearDesk: () => set({ ...empty, hydrated: true }),
    }),
    {
      name: "oratory-desk",
      skipHydration: true,
      partialize: (state) => ({
        lessons: state.lessons,
        readings: state.readings,
        exercises: state.exercises,
        journal: state.journal,
        sigils: state.sigils,
        cards: state.cards,
        streak: state.streak,
        lastDay: state.lastDay,
        recent: state.recent,
        intent: state.intent,
        sigilStatement: state.sigilStatement,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);

export function studiedCount(map: Record<string, number>) {
  return Object.keys(map).length;
}
