import type { Block } from "@/data/types";

export function Blocks({ blocks }: { blocks: Block[] }) {
  return (
    <div className="flex max-w-2xl flex-col gap-4">
      {blocks.map((block, index) => {
        if (block.type === "h") {
          return (
            <h2 key={index} className="mt-4 font-display text-2xl text-fg">
              {block.text}
            </h2>
          );
        }
        if (block.type === "quote") {
          return (
            <blockquote key={index} className="border-l-2 border-copper pl-4 text-fg">
              <p className="font-display text-xl leading-snug">{block.text}</p>
              {block.cite ? <footer className="mt-2 text-sm text-faint">{block.cite}</footer> : null}
            </blockquote>
          );
        }
        if (block.type === "steps") {
          return (
            <ol key={index} className="flex flex-col gap-3">
              {block.items.map((item, step) => (
                <li key={step} className="flex gap-3 rounded-2xl border border-line bg-surface px-4 py-3">
                  <span className="font-display text-copper">{step + 1}</span>
                  <span>{item}</span>
                </li>
              ))}
            </ol>
          );
        }
        if (block.type === "note") {
          return (
            <aside key={index} className="rounded-2xl border border-line bg-raised px-4 py-4">
              <p className="text-xs tracking-widest text-copper uppercase">
                {block.title ?? (block.tone === "caution" ? "Care" : "Source")}
              </p>
              <p className="mt-2 text-muted">{block.text}</p>
            </aside>
          );
        }
        if (block.type === "link") {
          return (
            <p key={index}>
              <a href={block.href} className="text-copper underline decoration-line underline-offset-4">
                {block.label}
              </a>
            </p>
          );
        }
        return <p key={index}>{block.text}</p>;
      })}
    </div>
  );
}
