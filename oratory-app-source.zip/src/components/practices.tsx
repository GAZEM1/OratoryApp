import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import { studyCards } from "@/data/cards";
import type { Exercise, StepItem } from "@/data/exercises";
import { useDesk } from "@/lib/desk-store";
import { PentagramGuide } from "@/components/pentagram";

const PHASES = [
  { id: "inhale", label: "Inhale", scale: 1 },
  { id: "hold-in", label: "Hold", scale: 1 },
  { id: "exhale", label: "Exhale", scale: 0.72 },
  { id: "hold-out", label: "Hold empty", scale: 0.72 },
] as const;

export function BreathPractice({ onDone }: { onDone: () => void }) {
  const [running, setRunning] = useState(false);
  const [ticks, setTicks] = useState(0);
  const totalRounds = 8;
  const round = Math.floor(ticks / 16);
  const still = round >= totalRounds;
  const phase = PHASES[Math.floor(ticks / 4) % PHASES.length];
  const left = 4 - (ticks % 4);

  useEffect(() => {
    if (!running || still) return;
    const timer = window.setInterval(() => setTicks((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [running, still]);

  return (
    <div className="max-w-xl">
      <div className="grid min-h-72 place-items-center rounded-2xl border border-line bg-surface">
        <div className="text-center">
          <div
            className="mx-auto grid size-36 place-items-center rounded-full border border-copper bg-raised transition-transform duration-1000"
            style={{ transform: `scale(${still ? 0.86 : phase.scale})` }}
          >
            <span className="font-display text-4xl text-copper">{still ? "—" : left}</span>
          </div>
          <p className="mt-5 font-display text-2xl">{still ? "Uncounted sit" : phase.label}</p>
          <p className="mt-1 text-sm text-muted">
            {still ? "Two minutes. No count. Then write." : `Round ${Math.min(round + 1, totalRounds)} of ${totalRounds}`}
          </p>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap gap-3">
        {still ? (
          <StillTail onDone={onDone} />
        ) : (
          <button
            type="button"
            className="h-11 rounded-full bg-copper px-5 text-copper-ink"
            onClick={() => setRunning((value) => !value)}
          >
            {running ? "Pause" : ticks === 0 ? "Begin" : "Resume"}
          </button>
        )}
      </div>
      <p className="mt-4 text-sm text-muted">
        If the holds make you panic, stop and breathe evenly instead. Drop the holds. Panic is not the exercise.
      </p>
    </div>
  );
}

function StillTail({ onDone }: { onDone: () => void }) {
  const [left, setLeft] = useState(120);
  const [run, setRun] = useState(true);
  useEffect(() => {
    if (!run) return;
    const timer = window.setInterval(() => {
      setLeft((value) => {
        if (value <= 1) {
          setRun(false);
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [run]);
  const minute = Math.floor(left / 60);
  const second = String(left % 60).padStart(2, "0");
  return (
    <>
      <p className="flex h-11 items-center text-muted">
        {left === 0 ? "The tail is done." : `${minute}:${second} of quiet`}
      </p>
      <button type="button" className="h-11 rounded-full bg-copper px-5 text-copper-ink" onClick={onDone}>
        Mark this sit
      </button>
    </>
  );
}

export function SitTimer({ onDone }: { onDone: () => void }) {
  const [seconds, setSeconds] = useState(10 * 60);
  const [running, setRunning] = useState(false);
  const total = 10 * 60;
  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => {
      setSeconds((value) => {
        if (value <= 1) {
          setRunning(false);
          chime();
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [running]);
  const minute = Math.floor(seconds / 60);
  const second = String(seconds % 60).padStart(2, "0");
  return (
    <div className="max-w-xl rounded-2xl border border-line bg-surface p-6">
      <p className="font-display text-6xl text-fg">
        {minute}:{second}
      </p>
      <p className="mt-2 text-muted">Ten minutes. Eyes soft. When the tone sounds, write before you talk.</p>
      <div className="mt-6 flex flex-wrap gap-3">
        <button
          type="button"
          className="h-11 rounded-full bg-copper px-5 text-copper-ink"
          onClick={() => setRunning((value) => !value)}
        >
          {running ? "Pause" : seconds === total ? "Start the sit" : seconds === 0 ? "Sit again" : "Resume"}
        </button>
        <button type="button" className="h-11 rounded-full border border-line px-5" onClick={onDone}>
          Mark practiced
        </button>
      </div>
    </div>
  );
}

function chime() {
  try {
    const context = new AudioContext();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.frequency.value = 432;
    oscillator.type = "sine";
    gain.gain.setValueAtTime(0.0001, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.08, context.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 1.4);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start();
    oscillator.stop(context.currentTime + 1.5);
  } catch {
    /* sound is optional */
  }
}

export function StepPractice({
  steps,
  showPentagram,
  onDone,
}: {
  steps: StepItem[];
  showPentagram?: boolean;
  onDone: () => void;
}) {
  const [done, setDone] = useState<boolean[]>(() => steps.map(() => false));
  const finished = done.every(Boolean);
  return (
    <div className="max-w-2xl">
      {showPentagram ? <PentagramGuide /> : null}
      <ol className="flex flex-col gap-3">
        {steps.map((step, index) => (
          <li key={step.title}>
            <button
              type="button"
              aria-pressed={done[index]}
              onClick={() =>
                setDone((current) => current.map((value, item) => (item === index ? !value : value)))
              }
              className={
                done[index]
                  ? "w-full rounded-2xl border border-copper bg-raised px-4 py-4 text-left"
                  : "w-full rounded-2xl border border-line bg-surface px-4 py-4 text-left"
              }
            >
              <span className="flex items-baseline gap-3">
                <span className="font-display text-copper">{done[index] ? "Done" : index + 1}</span>
                <span className="font-display text-xl">{step.title}</span>
              </span>
              <span className="mt-2 block text-muted">{step.detail}</span>
            </button>
          </li>
        ))}
      </ol>
      <button
        type="button"
        disabled={!finished}
        onClick={onDone}
        className="mt-4 h-11 rounded-full bg-copper px-5 text-copper-ink disabled:opacity-40"
      >
        {finished ? "Record the rehearsal" : "Mark each station first"}
      </button>
    </div>
  );
}

export function IntentBench() {
  const intent = useDesk((state) => state.intent);
  const setIntent = useDesk((state) => state.setIntent);
  const setSigilStatement = useDesk((state) => state.setSigilStatement);
  const markExercise = useDesk((state) => state.markExercise);
  const checks = useMemo(() => assessIntent(intent), [intent]);
  const ready = checks.every((check) => check.ok) && intent.trim().length > 0;

  return (
    <div className="max-w-2xl">
      <label className="block text-sm text-muted" htmlFor="intent">
        One sentence
      </label>
      <textarea
        id="intent"
        value={intent}
        onChange={(event) => setIntent(event.target.value)}
        rows={4}
        placeholder="I sleep through the night."
        className="mt-2 w-full rounded-2xl border border-line bg-raised px-4 py-3 text-fg"
      />
      <ul className="mt-4 flex flex-col gap-2">
        {checks.map((check) => (
          <li key={check.label} className="flex gap-3 text-sm">
            <span className={check.ok ? "text-copper" : "text-faint"}>{check.ok ? "Pass" : "Rework"}</span>
            <span className="text-muted">{check.label}</span>
          </li>
        ))}
      </ul>
      <div className="mt-5 flex flex-wrap gap-3">
        <button
          type="button"
          disabled={!ready}
          onClick={() => markExercise("statement")}
          className="h-11 rounded-full bg-copper px-5 text-copper-ink disabled:opacity-40"
        >
          Keep this sentence
        </button>
        <Link
          to="/practice/$exerciseId"
          params={{ exerciseId: "sigil-atelier" }}
          onClick={() => setSigilStatement(intent.trim())}
          className="inline-flex h-11 items-center rounded-full border border-line px-5"
        >
          Use it on the sigil bench
        </Link>
      </div>
    </div>
  );
}

function assessIntent(value: string) {
  const text = value.trim();
  const lower = ` ${text.toLowerCase()} `;
  const other =
    /\b(he|she|they|him|her|them|his|their)\b/i.test(text) ||
    /\bmake (him|her|them)\b/i.test(lower);
  return [
    { ok: text.length > 8, label: "Long enough to be a real change, short enough to say aloud." },
    { ok: (text.match(/[.!?]/g) ?? []).length <= 1, label: "One sentence." },
    { ok: !/\b(not|don't|dont|never|stop|won't|wont|no)\b/i.test(text), label: "States the wanted thing. No negation." },
    { ok: !/\b(try|hope|wish|maybe|should)\b/i.test(text), label: "No try, hope, or maybe." },
    { ok: !/^i will\b/i.test(text), label: "Present tense. Not 'I will'." },
    { ok: !other, label: "About your conduct, not someone else's will." },
  ];
}

export function letterPool(statement: string) {
  const consonants = statement.toUpperCase().replace(/[^A-Z]/g, "").replace(/[AEIOU]/g, "");
  let out = "";
  const seen = new Set<string>();
  for (const char of consonants) {
    if (seen.has(char)) continue;
    seen.add(char);
    out += char;
  }
  return out;
}

export function SigilBench() {
  const statement = useDesk((state) => state.sigilStatement);
  const setStatement = useDesk((state) => state.setSigilStatement);
  const addSigil = useDesk((state) => state.addSigil);
  const sigils = useDesk((state) => state.sigils);
  const hydrated = useDesk((state) => state.hydrated);
  const removeSigil = useDesk((state) => state.removeSigil);
  const letters = letterPool(statement);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const strokes = useRef<{ x: number; y: number }[][]>([]);
  const drawing = useRef<{ x: number; y: number }[] | null>(null);
  const lettersOn = useRef(false);
  const [saved, setSaved] = useState(false);

  function resize() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    redraw();
  }

  useEffect(() => {
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
    // mount only
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function point(event: ReactPointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) / rect.width) * canvas.width,
      y: ((event.clientY - rect.top) / rect.height) * canvas.height,
    };
  }

  function redraw() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (lettersOn.current && letters.length > 0) {
      ctx.fillStyle = "#f4eee6";
      ctx.font = `${Math.floor(canvas.width / 14)}px Fraunces, Palatino, serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const radius = canvas.width / 5;
      letters.split("").forEach((char, index) => {
        const angle = -Math.PI / 2 + (index / letters.length) * Math.PI * 2;
        ctx.save();
        ctx.translate(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius);
        ctx.rotate(angle + Math.PI / 2);
        ctx.fillText(char, 0, 0);
        ctx.restore();
      });
    }
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "#e08a55";
    ctx.lineWidth = Math.max(3, canvas.width / 140);
    for (const stroke of strokes.current) {
      if (stroke.length < 2) continue;
      ctx.beginPath();
      ctx.moveTo(stroke[0].x, stroke[0].y);
      for (const pt of stroke.slice(1)) ctx.lineTo(pt.x, pt.y);
      ctx.stroke();
    }
  }

  function layLetters() {
    if (letters.length === 0) return;
    lettersOn.current = true;
    redraw();
  }

  function save() {
    const canvas = canvasRef.current;
    if (!canvas || letters.length < 2) return;
    try {
      const image = canvas.toDataURL("image/jpeg", 0.7);
      addSigil({ statement: statement.trim(), letters, image });
      setSaved(true);
    } catch {
      setSaved(false);
    }
  }

  return (
    <div className="max-w-2xl">
      <label className="block text-sm text-muted" htmlFor="sigil-statement">
        Statement, then let the letters reduce it
      </label>
      <textarea
        id="sigil-statement"
        value={statement}
        onChange={(event) => {
          setStatement(event.target.value);
          setSaved(false);
        }}
        rows={3}
        className="mt-2 w-full rounded-2xl border border-line bg-raised px-4 py-3"
        placeholder="I keep the evening hour."
      />
      <p className="mt-4 text-xs tracking-widest text-faint uppercase">Letter pool</p>
      <p className="mt-1 font-display text-3xl tracking-widest">{letters || "—"}</p>
      <p className="mt-1 text-sm text-muted">Vowels gone. Repeats gone. Draw until the letters are no longer a sentence.</p>
      <canvas
        ref={canvasRef}
        className="mt-4 h-80 w-full touch-none rounded-2xl border border-line bg-bg"
        onPointerDown={(event: ReactPointerEvent<HTMLCanvasElement>) => {
          event.currentTarget.setPointerCapture(event.pointerId);
          drawing.current = [point(event)];
          strokes.current.push(drawing.current);
        }}
        onPointerMove={(event: ReactPointerEvent<HTMLCanvasElement>) => {
          if (!drawing.current) return;
          drawing.current.push(point(event));
          redraw();
        }}
        onPointerUp={() => {
          drawing.current = null;
        }}
      />
      <div className="mt-4 flex flex-wrap gap-3">
        <button type="button" className="h-11 rounded-full border border-line px-4" onClick={layLetters}>
          Lay the letters
        </button>
        <button
          type="button"
          className="h-11 rounded-full border border-line px-4"
          onClick={() => {
            strokes.current.pop();
            resize();
          }}
        >
          Undo stroke
        </button>
        <button
          type="button"
          className="h-11 rounded-full border border-line px-4"
          onClick={() => {
            strokes.current = [];
            lettersOn.current = false;
            resize();
          }}
        >
          Clear
        </button>
        <button
          type="button"
          disabled={letters.length < 2}
          onClick={save}
          className="h-11 rounded-full bg-copper px-5 text-copper-ink disabled:opacity-40"
        >
          Put the sigil away
        </button>
      </div>
      {saved ? (
        <p className="mt-3 text-sm text-muted">
          Saved on this desk. Do not keep looking at it. Give the result a date in the diary and leave it alone.
        </p>
      ) : null}
      {hydrated && sigils.length > 0 ? (
        <ul className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {sigils.map((sigil) => (
            <li key={sigil.id} className="rounded-2xl border border-line bg-surface p-2">
              <img src={sigil.image} alt="Saved sigil" className="aspect-square w-full rounded-xl bg-bg object-contain" />
              <p className="mt-2 truncate px-1 text-xs text-faint">{sigil.letters}</p>
              <button type="button" className="mt-1 h-10 px-1 text-sm text-muted" onClick={() => removeSigil(sigil.id)}>
                Dismiss
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

export function CardDrill({ onDone }: { onDone: () => void }) {
  const memories = useDesk((state) => state.cards);
  const gradeCard = useDesk((state) => state.gradeCard);
  const hydrated = useDesk((state) => state.hydrated);
  const [index, setIndex] = useState(0);
  const [shown, setShown] = useState(false);
  const [seen, setSeen] = useState(0);
  const queue = useMemo(() => {
    const now = Date.now();
    const due = studyCards.filter((card) => {
      const memory = memories[card.id];
      return !memory || memory.due <= now;
    });
    return due.length > 0 ? due : studyCards;
  }, [memories, hydrated]);
  const card = queue[index % queue.length];

  if (!card) return null;

  return (
    <div className="max-w-xl">
      <p className="text-xs tracking-widest text-faint uppercase">{card.tag}</p>
      <button
        type="button"
        onClick={() => setShown(true)}
        className="mt-3 min-h-48 w-full rounded-2xl border border-line bg-surface px-5 py-6 text-left"
      >
        <span className="font-display text-3xl">{shown ? card.back : card.front}</span>
        {!shown ? <span className="mt-4 block text-sm text-muted">Show the answer</span> : null}
      </button>
      {shown ? (
        <div className="mt-4 flex gap-3">
          <button
            type="button"
            className="h-11 flex-1 rounded-full border border-line"
            onClick={() => {
              gradeCard(card.id, false);
              setShown(false);
              setIndex((value) => value + 1);
              setSeen((value) => value + 1);
            }}
          >
            Again
          </button>
          <button
            type="button"
            className="h-11 flex-1 rounded-full bg-copper text-copper-ink"
            onClick={() => {
              gradeCard(card.id, true);
              setShown(false);
              setIndex((value) => value + 1);
              const next = seen + 1;
              setSeen(next);
              if (next >= 6) onDone();
            }}
          >
            Known
          </button>
        </div>
      ) : null}
      <p className="mt-3 text-sm text-muted">
        {hydrated ? `${queue.length} in this pass.` : "Opening the pack."} Six known cards records the practice.
      </p>
    </div>
  );
}

export function PracticeBody({ exercise, onDone }: { exercise: Exercise; onDone: () => void }) {
  if (exercise.kind === "breath") return <BreathPractice onDone={onDone} />;
  if (exercise.kind === "timer") return <SitTimer onDone={onDone} />;
  if (exercise.kind === "steps" && exercise.steps) {
    return (
      <StepPractice steps={exercise.steps} showPentagram={exercise.id === "lbrp-rehearsal"} onDone={onDone} />
    );
  }
  if (exercise.kind === "intent") return <IntentBench />;
  if (exercise.kind === "sigil") return <SigilBench />;
  if (exercise.kind === "cards") return <CardDrill onDone={onDone} />;
  if (exercise.kind === "diary") {
    return (
      <p>
        <Link to="/journal" className="inline-flex h-11 items-center rounded-full bg-copper px-5 text-copper-ink">
          Open the diary
        </Link>
      </p>
    );
  }
  return null;
}
