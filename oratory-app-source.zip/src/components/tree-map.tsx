import { useState } from "react";
import { sephirahById, sephiroth, treePaths } from "@/data/tree";

export function TreeMap() {
  const [selected, setSelected] = useState("tiphareth");
  const sphere = sephirahById(selected) ?? sephiroth[5];
  const touching = treePaths.filter((path) => path.from === selected || path.to === selected);

  return (
    <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,280px)_1fr]">
      <div className="rounded-2xl border border-line bg-surface p-3">
        <svg viewBox="0 0 320 560" className="mx-auto w-full max-w-xs" role="group" aria-label="Tree of Life">
          {treePaths.map((path) => {
            const from = sephirahById(path.from);
            const to = sephirahById(path.to);
            if (!from || !to) return null;
            const hot = path.from === selected || path.to === selected;
            return (
              <line
                key={path.n}
                x1={from.x}
                y1={from.y}
                x2={to.x}
                y2={to.y}
                stroke={hot ? "var(--color-copper)" : "var(--color-line)"}
                strokeWidth={hot ? 2 : 1}
              />
            );
          })}
          <line
            x1="160"
            y1="70"
            x2="160"
            y2="230"
            stroke="var(--color-faint)"
            strokeDasharray="3 6"
            strokeWidth="1"
          />
          <text x="172" y="168" fill="var(--color-faint)" fontSize="11" fontFamily="var(--font-body)">
            Daath
          </text>
          {sephiroth.map((item) => {
            const on = item.id === selected;
            return (
              <g
                key={item.id}
                role="button"
                tabIndex={0}
                aria-pressed={on}
                aria-label={`${item.n}. ${item.name}, ${item.meaning}`}
                onClick={() => setSelected(item.id)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    setSelected(item.id);
                  }
                }}
                className="cursor-pointer"
              >
                <circle
                  cx={item.x}
                  cy={item.y}
                  r="20"
                  fill={on ? "var(--color-copper)" : "var(--color-raised)"}
                  stroke={on ? "var(--color-copper)" : "var(--color-muted)"}
                  strokeWidth="1.5"
                />
                <text
                  x={item.x}
                  y={item.y + 4}
                  textAnchor="middle"
                  fontSize="13"
                  fill={on ? "var(--color-copper-ink)" : "var(--color-fg)"}
                  fontFamily="var(--font-display)"
                >
                  {item.n}
                </text>
              </g>
            );
          })}
        </svg>
        <p className="px-2 pb-2 text-sm text-faint">Tap a sphere. Paths in copper touch it.</p>
      </div>
      <article className="rounded-2xl border border-line bg-surface p-5">
        <p className="text-xs tracking-widest text-copper uppercase">
          {sphere.n}. {sphere.planet}
        </p>
        <h2 className="mt-2 font-display text-3xl">
          {sphere.name}
          <span className="ml-3 text-xl text-muted">{sphere.meaning}</span>
        </h2>
        <p className="mt-4">{sphere.idea}</p>
        <p className="mt-3 text-muted">{sphere.study}</p>
        <h3 className="mt-6 font-display text-xl">Paths that touch it</h3>
        <ul className="mt-3 flex flex-col gap-2">
          {touching.map((path) => {
            const other = sephirahById(path.from === selected ? path.to : path.from);
            return (
              <li key={path.n} className="rounded-xl border border-line bg-bg px-3 py-3">
                <p className="text-sm text-copper">
                  {path.n}. {path.letter} {path.hebrew} · {path.card}
                </p>
                <p className="mt-1">
                  Toward {other?.name}. {path.note}
                </p>
              </li>
            );
          })}
        </ul>
      </article>
    </div>
  );
}
