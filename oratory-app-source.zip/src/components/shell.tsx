import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, Flame, Home, Library, PenLine, Route } from "lucide-react";
import type { ReactNode } from "react";

const NAV = [
  { href: "/", label: "Desk", long: "Desk", icon: Home },
  { href: "/paths", label: "Paths", long: "Paths", icon: Route },
  { href: "/library", label: "Read", long: "Library", icon: Library },
  { href: "/practice", label: "Work", long: "Practice", icon: Flame },
  { href: "/journal", label: "Log", long: "Diary", icon: PenLine },
] as const;

function active(path: string, href: string) {
  if (href === "/") return path === "/";
  return path === href || path.startsWith(`${href}/`);
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex w-full max-w-6xl">
        <aside className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-line px-5 py-7 md:flex">
          <Link to="/" className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-xl bg-copper font-display text-lg text-copper-ink">
              O
            </span>
            <span>
              <span className="block font-display text-xl leading-none">Oratory</span>
              <span className="mt-1 block text-xs tracking-widest text-faint uppercase">Study desk</span>
            </span>
          </Link>
          <nav className="mt-10 flex flex-col gap-1">
            {NAV.map((item) => {
              const on = active(path, item.href);
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={
                    on
                      ? "flex h-11 items-center gap-3 rounded-xl bg-raised px-3 text-fg"
                      : "flex h-11 items-center gap-3 rounded-xl px-3 text-muted hover:bg-surface hover:text-fg"
                  }
                >
                  <Icon className="size-4" aria-hidden />
                  {item.long}
                </Link>
              );
            })}
            <Link
              to="/theory"
              className={
                active(path, "/theory")
                  ? "mt-2 flex h-11 items-center gap-3 rounded-xl bg-raised px-3 text-fg"
                  : "mt-2 flex h-11 items-center gap-3 rounded-xl px-3 text-muted hover:bg-surface hover:text-fg"
              }
            >
              <BookOpen className="size-4" aria-hidden />
              Theory
            </Link>
          </nav>
          <p className="mt-auto text-sm text-faint">Notes for study. Not a lineage, and not medicine.</p>
        </aside>
        <div className="min-w-0 flex-1 px-4 pt-6 pb-28 md:px-8 md:pt-8 md:pb-16">{children}</div>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg md:hidden">
        <ul className="mx-auto grid max-w-lg grid-cols-5">
          {NAV.map((item) => {
            const on = active(path, item.href);
            const Icon = item.icon;
            return (
              <li key={item.href}>
                <Link
                  to={item.href}
                  className={
                    on
                      ? "flex h-16 flex-col items-center justify-center gap-1 text-copper"
                      : "flex h-16 flex-col items-center justify-center gap-1 text-faint"
                  }
                >
                  <Icon className="size-5" aria-hidden />
                  <span className="text-xs">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

export function Title({
  kicker,
  title,
  lede,
}: {
  kicker?: string;
  title: string;
  lede?: string;
}) {
  return (
    <header className="mb-8 max-w-2xl">
      {kicker ? <p className="mb-2 text-xs tracking-widest text-copper uppercase">{kicker}</p> : null}
      <h1 className="font-display text-3xl leading-tight text-fg md:text-4xl">{title}</h1>
      {lede ? <p className="mt-3 text-muted">{lede}</p> : null}
    </header>
  );
}

export function Back({
  href,
  label,
}: {
  href: "/" | "/paths" | "/library" | "/practice" | "/journal" | "/theory";
  label: string;
}) {
  return (
    <Link to={href} className="mb-6 inline-flex h-11 items-center text-sm text-muted hover:text-fg">
      {label}
    </Link>
  );
}
