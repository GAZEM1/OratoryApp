import { useEffect } from "react";
import { useDesk } from "@/lib/desk-store";

export function DeskHydrator() {
  useEffect(() => {
    void Promise.resolve(useDesk.persist.rehydrate()).finally(() => {
      if (!useDesk.getState().hydrated) useDesk.getState().setHydrated(true);
    });
  }, []);
  return null;
}
