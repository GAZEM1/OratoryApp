const ORDER = [3, 0, 2, 4, 1, 3];

function vertices(cx: number, cy: number, radius: number) {
  return Array.from({ length: 5 }, (_, index) => {
    const angle = ((-90 + index * 72) * Math.PI) / 180;
    return { x: cx + radius * Math.cos(angle), y: cy + radius * Math.sin(angle) };
  });
}

export function PentagramGuide() {
  const points = vertices(120, 124, 88);
  const stroke = ORDER.map((index) => points[index]);
  const d = stroke.map((point, index) => `${index === 0 ? "M" : "L"} ${point.x.toFixed(1)} ${point.y.toFixed(1)}`).join(" ");
  const labels = [
    { n: 2, at: 0 },
    { n: 5, at: 1 },
    { n: 3, at: 2 },
    { n: 1, at: 3 },
    { n: 4, at: 4 },
  ];

  return (
    <figure className="my-6 max-w-sm rounded-2xl border border-line bg-surface p-4">
      <svg viewBox="0 0 240 250" className="w-full" role="img" aria-labelledby="pentagram-title pentagram-desc">
        <title id="pentagram-title">Banishing earth pentagram</title>
        <desc id="pentagram-desc">
          A point-up pentagram. The banishing stroke starts at the lower left, rises to the top, and continues until it closes.
        </desc>
        <polygon
          points={points.map((point) => `${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(" ")}
          fill="none"
          stroke="var(--color-line)"
          strokeWidth="1"
        />
        <path d={d} fill="none" stroke="var(--color-copper)" strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
        {labels.map((label) => {
          const point = points[label.at];
          return (
            <g key={label.n}>
              <circle cx={point.x} cy={point.y} r="11" fill="var(--color-copper)" />
              <text
                x={point.x}
                y={point.y + 4}
                textAnchor="middle"
                fontSize="12"
                fill="var(--color-copper-ink)"
                fontFamily="var(--font-display)"
              >
                {label.n}
              </text>
            </g>
          );
        })}
      </svg>
      <figcaption className="text-sm text-muted">
        Banishing earth. Begin at 1, the lower left, and follow the numbers back to the start. The lesser ritual uses this figure at all four quarters.
      </figcaption>
    </figure>
  );
}
