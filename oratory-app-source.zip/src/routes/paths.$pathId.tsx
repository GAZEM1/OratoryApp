import { createFileRoute, Link } from "@tanstack/react-router";
import { paths } from "@/data/curriculum";
import { Back, Shell, Title } from "@/components/shell";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/paths/$pathId")({ component: PathPage });

function PathPage() {
  const { pathId } = Route.useParams();
  const path = paths.find((item) => item.id === pathId);
  const lessons = useDesk((state) => state.lessons);
  const hydrated = useDesk((state) => state.hydrated);

  if (!path) {
    return (
      <Shell>
        <Back href="/paths" label="All paths" />
        <Title title="That path is not on the desk." />
      </Shell>
    );
  }

  return (
    <Shell>
      <Back href="/paths" label="All paths" />
      <Title kicker={path.kicker} title={path.title} lede={path.blurb} />
      <ol className="flex max-w-2xl flex-col gap-3">
        {path.lessons.map((lesson, index) => {
          const done = hydrated && lessons[lesson.id];
          return (
            <li key={lesson.id}>
              <Link
                to="/lessons/$lessonId"
                params={{ lessonId: lesson.id }}
                className="flex items-baseline justify-between gap-4 rounded-2xl border border-line bg-surface px-4 py-4"
              >
                <span>
                  <span className="mr-3 font-display text-copper">{index + 1}</span>
                  <span className="font-display text-xl">{lesson.title}</span>
                  <span className="mt-1 block pl-7 text-sm text-faint">{lesson.minutes} min</span>
                </span>
                <span className="shrink-0 text-sm text-muted">{done ? "Studied" : "Open"}</span>
              </Link>
            </li>
          );
        })}
      </ol>
    </Shell>
  );
}
