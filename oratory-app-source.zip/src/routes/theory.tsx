import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Title } from "@/components/shell";
import { TreeMap } from "@/components/tree-map";
import { pillars } from "@/data/tree";

const QUARTERS = [
  { id: "n", name: "North", element: "Earth", angel: "Auriel", place: "At your left hand when you face east." },
  { id: "e", name: "East", element: "Air", angel: "Raphael", place: "The direction you face to begin." },
  { id: "s", name: "South", element: "Fire", angel: "Michael", place: "At your right hand when you face east." },
  { id: "w", name: "West", element: "Water", angel: "Gabriel", place: "Behind you when you face east." },
];

const MODELS = [
  ["Spirit", "Persons who are not human", "Silence, flattery, obsession", "Manners: open, constrain, license to depart"],
  ["Energy", "A charge the body moves", "No sleep, fried nerves", "Circulate it, then banish"],
  ["Psychological", "Symbol working the operator", "A mood mistaken for a message", "A diary that can catch you"],
  ["Information", "A compressed instruction", "An intent too vague to fail", "One falsifiable sentence"],
  ["Meta", "Whichever model you chose on purpose", "Switching the story afterward", "Write the model before you begin"],
];

export const Route = createFileRoute("/theory")({ component: TheoryPage });

function TheoryPage() {
  const [quarter, setQuarter] = useState("e");
  const active = QUARTERS.find((item) => item.id === quarter) ?? QUARTERS[1];

  return (
    <Shell>
      <Title
        kicker="Theory"
        title="Maps, not souvenirs."
        lede="The Hermetic tree, the Golden Dawn quarters, and five models you can actually name in a diary."
      />

      <section>
        <h2 className="font-display text-2xl">Tree of Life</h2>
        <p className="mt-2 mb-4 max-w-2xl text-muted">
          Ten sephiroth, twenty-two paths, Golden Dawn letter and tarot pairings. Jewish trees are not identical. Daath is marked and not counted.
        </p>
        <TreeMap />
        <ul className="mt-4 grid gap-3 md:grid-cols-3">
          {pillars.map((pillar) => (
            <li key={pillar.name} className="rounded-2xl border border-line bg-surface p-4">
              <p className="text-xs tracking-widest text-copper uppercase">{pillar.side}</p>
              <p className="mt-1 font-display text-xl">{pillar.name}</p>
              <p className="mt-1 text-sm text-faint">{pillar.sephiroth}</p>
              <p className="mt-2 text-sm text-muted">{pillar.text}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-12">
        <h2 className="font-display text-2xl">Quarters</h2>
        <p className="mt-2 max-w-2xl text-muted">
          This is a map with north at the top. In the lodge you face east, so east is in front of you. These are Golden Dawn quarters. Other traditions turn the wheel.
        </p>
        <div className="mt-4 grid max-w-md grid-cols-3 gap-2">
          <span />
          <QuarterButton id="n" label="North" current={quarter} onPick={setQuarter} />
          <span />
          <QuarterButton id="w" label="West" current={quarter} onPick={setQuarter} />
          <div className="grid min-h-16 place-items-center rounded-2xl border border-line bg-bg px-2 text-center text-sm text-faint">
            Face east
          </div>
          <QuarterButton id="e" label="East" current={quarter} onPick={setQuarter} />
          <span />
          <QuarterButton id="s" label="South" current={quarter} onPick={setQuarter} />
          <span />
        </div>
        <article className="mt-4 max-w-xl rounded-2xl border border-line bg-surface p-5">
          <p className="text-xs tracking-widest text-copper uppercase">{active.element}</p>
          <h3 className="mt-1 font-display text-3xl">{active.name}</h3>
          <p className="mt-2">{active.angel}.</p>
          <p className="mt-1 text-muted">{active.place}</p>
        </article>
      </section>

      <section className="mt-12 max-w-3xl">
        <h2 className="font-display text-2xl">Models</h2>
        <p className="mt-2 mb-4 text-muted">Pick one before a working. Write it down. Do not change it after you see the result.</p>
        <div className="overflow-x-auto rounded-2xl border border-line">
          <table className="w-full min-w-xl text-left text-sm">
            <thead className="bg-raised text-faint">
              <tr>
                <th className="px-3 py-3 font-semibold">Model</th>
                <th className="px-3 py-3 font-semibold">Change comes from</th>
                <th className="px-3 py-3 font-semibold">Failure looks like</th>
                <th className="px-3 py-3 font-semibold">So you</th>
              </tr>
            </thead>
            <tbody>
              {MODELS.map((row) => (
                <tr key={row[0]} className="border-t border-line bg-surface align-top">
                  {row.map((cell) => (
                    <td key={cell} className="px-3 py-3">
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </Shell>
  );
}

function QuarterButton({
  id,
  label,
  current,
  onPick,
}: {
  id: string;
  label: string;
  current: string;
  onPick: (id: string) => void;
}) {
  const on = id === current;
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={() => onPick(id)}
      className={
        on
          ? "min-h-16 rounded-2xl bg-copper px-2 text-copper-ink"
          : "min-h-16 rounded-2xl border border-line bg-surface px-2"
      }
    >
      {label}
    </button>
  );
}
