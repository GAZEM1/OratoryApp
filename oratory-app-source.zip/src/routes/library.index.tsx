import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { readings } from "@/data/library";
import { Shell, Title } from "@/components/shell";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/library/")({ component: LibraryPage });

function LibraryPage() {
  const [query, setQuery] = useState("");
  const done = useDesk((state) => state.readings);
  const hydrated = useDesk((state) => state.hydrated);
  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return readings;
    return readings.filter((reading) => `${reading.title} ${reading.shelf}`.toLowerCase().includes(needle));
  }, [query]);

  return (
    <Shell>
      <Title
        kicker="Library"
        title="The shelf."
        lede="Essays written for this desk. Dates, lineages, and arguments stay attached to the ideas."
      />
      <label className="mb-5 block max-w-md">
        <span className="sr-only">Search the shelf</span>
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search titles"
          className="h-12 w-full rounded-full border border-line bg-surface px-4"
        />
      </label>
      <ul className="grid gap-3 md:grid-cols-2">
        {filtered.map((reading) => (
          <li key={reading.id}>
            <Link to="/library/$readingId" params={{ readingId: reading.id }} className="block h-full rounded-2xl border border-line bg-surface p-5">
              <span className="text-xs tracking-widest text-copper uppercase">{reading.shelf}</span>
              <span className="mt-2 block font-display text-2xl">{reading.title}</span>
              <span className="mt-3 block text-sm text-faint">
                {reading.minutes} min{hydrated && done[reading.id] ? " · Read" : ""}
              </span>
            </Link>
          </li>
        ))}
      </ul>
      {filtered.length === 0 ? <p className="mt-6 text-muted">Nothing on the shelf matches that.</p> : null}
    </Shell>
  );
}
