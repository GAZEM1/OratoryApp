import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/paths")({
  component: () => <Outlet />,
});
