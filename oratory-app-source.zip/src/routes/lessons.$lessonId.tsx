import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { Blocks } from "@/components/blocks";
import { PentagramGuide } from "@/components/pentagram";
import { Back, Shell, Title } from "@/components/shell";
import { lessonPath } from "@/data/curriculum";
import { findExercise } from "@/data/exercises";
import { findReading } from "@/data/library";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/lessons/$lessonId")({ component: LessonPage });

function LessonPage() {
  const { lessonId } = Route.useParams();
  const found = lessonPath(lessonId);
  const markLesson = useDesk((state) => state.markLesson);
  const remember = useDesk((state) => state.remember);
  const done = useDesk((state) => Boolean(state.lessons[lessonId]));
  const hydrated = useDesk((state) => state.hydrated);

  useEffect(() => {
    if (found) remember("lesson", lessonId);
  }, [found, lessonId, remember]);

  if (!found) {
    return (
      <Shell>
        <Back href="/paths" label="All paths" />
        <Title title="That lesson is not on the desk." />
      </Shell>
    );
  }

  const { path, lesson, index } = found;
  const previous = path.lessons[index - 1];
  const next = path.lessons[index + 1];
  const exercise = lesson.exerciseId ? findExercise(lesson.exerciseId) : null;
  const reading = lesson.readingId ? findReading(lesson.readingId) : null;

  return (
    <Shell>
      <Link
        to="/paths/$pathId"
        params={{ pathId: path.id }}
        className="mb-6 inline-flex h-11 items-center text-sm text-muted hover:text-fg"
      >
        {path.title}
      </Link>
      <Title kicker={`${path.title} · ${lesson.minutes} min`} title={lesson.title} />
      <Blocks blocks={lesson.blocks} />
      {lesson.diagram === "pentagram" ? <PentagramGuide /> : null}
      <div className="mt-8 flex max-w-2xl flex-col gap-3">
        {exercise ? (
          <Link
            to="/practice/$exerciseId"
            params={{ exerciseId: exercise.id }}
            className="rounded-2xl border border-line bg-raised px-4 py-4"
          >
            <span className="text-xs tracking-widest text-copper uppercase">Practice</span>
            <span className="mt-1 block font-display text-xl">{exercise.title}</span>
          </Link>
        ) : null}
        {reading ? (
          <Link to="/library/$readingId" params={{ readingId: reading.id }} className="text-copper underline decoration-line underline-offset-4">
            Further reading: {reading.title}
          </Link>
        ) : null}
      </div>
      <div className="mt-8 flex max-w-2xl flex-wrap items-center gap-3 border-t border-line pt-6">
        <button type="button" className="h-11 rounded-full bg-copper px-5 text-copper-ink" onClick={() => markLesson(lesson.id)}>
          {hydrated && done ? "Studied again" : "Mark as studied"}
        </button>
        {hydrated && done ? <span className="text-sm text-muted">On the record.</span> : null}
        {previous ? (
          <Link to="/lessons/$lessonId" params={{ lessonId: previous.id }} className="inline-flex h-11 items-center text-sm text-muted">
            Previous
          </Link>
        ) : null}
        {next ? (
          <Link to="/lessons/$lessonId" params={{ lessonId: next.id }} className="inline-flex h-11 items-center text-sm text-muted">
            Next
          </Link>
        ) : null}
      </div>
    </Shell>
  );
}
