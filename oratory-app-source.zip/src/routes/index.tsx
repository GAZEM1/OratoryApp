import { createFileRoute, Link } from "@tanstack/react-router";
import { lessonCount, lessonPath, paths } from "@/data/curriculum";
import { exerciseForDate, exercises, findExercise } from "@/data/exercises";
import { findReading, readings } from "@/data/library";
import { Shell, Title } from "@/components/shell";
import { useDesk } from "@/lib/desk-store";

const PROMPTS = [
  "Write the change you want in one sentence. Cut every word that is not the change.",
  "Name the model you are using today: spirit, energy, psyche, information, or undecided.",
  "Face your chosen east wall and do the cross once, even if you remember only the gestures.",
  "Read one page and write what it wants you to do before the next meal.",
  "Record the condition of the body before you record the vision.",
  "Pick one sephirah and live in it for an hour. Say which one.",
  "If a working has no close, it is not finished. Close something you opened.",
  "Make the sigil, then put it where you will not check it.",
  "Saturn's question: what are you calling practice that is only costume?",
  "Translate a symbol into three plain sentences. If you cannot, you do not have it yet.",
  "Give the week its planet. Do one act in that style and write the line.",
  "Boredom is a result. Write it with the same pen you would use for a vision.",
  "Outline a ritual's bones: open, declare, operate, close, record. Do not perform a new one.",
  "After the work, do one ordinary next thing. Magick that cannot land is a mood.",
];

export const Route = createFileRoute("/")({ component: Desk });

function Desk() {
  const hydrated = useDesk((state) => state.hydrated);
  const lessons = useDesk((state) => state.lessons);
  const readingsDone = useDesk((state) => state.readings);
  const exerciseMap = useDesk((state) => state.exercises);
  const recent = useDesk((state) => state.recent);
  const streak = useDesk((state) => state.streak);
  const journal = useDesk((state) => state.journal);
  const today = new Date();
  const prompt = PROMPTS[dayOfYear(today) % PROMPTS.length];
  const suggested = exerciseForDate(today);
  const latest = recent[0];
  const studied = Object.keys(lessons).length;

  return (
    <Shell>
      <Title
        kicker="Oratory"
        title="The desk is open."
        lede="Reading, theory, and practice for the study of magick. The record stays on this device."
      />
      <p className="mb-6 max-w-2xl text-muted" suppressHydrationWarning>
        {today.toLocaleDateString("en-NZ", { weekday: "long", day: "numeric", month: "long" })}. {prompt}
      </p>
      <div className="grid items-start gap-4 lg:grid-cols-3">
        <section className="flex flex-col gap-4 lg:col-span-2">
          <ContinueCard latest={hydrated ? latest : undefined} studied={hydrated ? studied : null} />
          <div className="rounded-2xl border border-line bg-surface p-5">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="font-display text-2xl">Paths</h2>
              <Link to="/paths" className="text-sm text-copper">
                All paths
              </Link>
            </div>
            <ul className="mt-4 flex flex-col gap-3">
              {paths.map((path) => {
                const done = path.lessons.filter((lesson) => lessons[lesson.id]).length;
                const width = `${Math.round((done / path.lessons.length) * 100)}%`;
                return (
                  <li key={path.id}>
                    <Link to="/paths/$pathId" params={{ pathId: path.id }} className="block">
                      <span className="flex items-baseline justify-between gap-3">
                        <span className="font-display text-xl">{path.title}</span>
                        <span className="text-sm text-faint">
                          {hydrated ? `${done}/${path.lessons.length}` : "—"}
                        </span>
                      </span>
                      <span className="mt-2 block h-1 rounded-full bg-raised">
                        <span className="block h-1 rounded-full bg-copper" style={{ width: hydrated ? width : "0%" }} />
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        </section>
        <aside className="flex flex-col gap-4">
          <Link to="/practice/$exerciseId" params={{ exerciseId: suggested.id }} className="rounded-2xl border border-line bg-raised p-5">
            <p className="text-xs tracking-widest text-copper uppercase">Today's work</p>
            <p className="mt-2 font-display text-2xl">{suggested.title}</p>
            <p className="mt-2 text-sm text-muted">{suggested.summary}</p>
          </Link>
          <div className="rounded-2xl border border-line bg-surface p-5">
            <p className="text-xs tracking-widest text-faint uppercase">Days kept</p>
            <p className="mt-1 font-display text-4xl">{hydrated ? streak : "—"}</p>
            <p className="mt-2 text-sm text-muted">
              {hydrated ? `${Object.keys(readingsDone).length} readings · ${Object.keys(exerciseMap).length} practices` : "Record opens on this device."}
            </p>
          </div>
          <Link to="/journal" className="rounded-2xl border border-line bg-surface p-5">
            <p className="text-xs tracking-widest text-faint uppercase">Diary</p>
            <p className="mt-2 text-muted">
              {hydrated && journal[0] ? journal[0].body.slice(0, 140) : "One line after practice is enough. Start with the condition of the body."}
            </p>
          </Link>
          <Link to="/theory" className="rounded-2xl border border-line bg-surface p-5">
            <p className="text-xs tracking-widest text-faint uppercase">Theory desk</p>
            <p className="mt-2 font-display text-xl">Tree, quarters, models</p>
          </Link>
        </aside>
      </div>
      <p className="mt-8 max-w-2xl text-sm text-faint">
        {exercises.length} practices and {readings.length} essays are on the desk. Study notes, not an initiation, and not a substitute for medical care.
      </p>
    </Shell>
  );
}

function dayOfYear(date: Date) {
  const start = new Date(date.getFullYear(), 0, 0);
  return Math.floor((date.getTime() - start.getTime()) / 86_400_000);
}

function ContinueCard({
  latest,
  studied,
}: {
  latest?: { kind: "lesson" | "reading" | "exercise"; id: string };
  studied: number | null;
}) {
  const body = (
    <>
      <p className="text-xs tracking-widest text-copper uppercase">Continue</p>
      <p className="mt-2 font-display text-2xl">
        {latest ? labelFor(latest.kind, latest.id) : "Start with Ground"}
      </p>
      <p className="mt-2 text-sm text-muted">
        {studied === null ? "Opening your record." : `${studied} of ${lessonCount()} lessons on the record.`}
      </p>
    </>
  );
  const className = "block rounded-2xl border border-line bg-surface p-5";
  if (!latest) {
    return (
      <Link to="/paths/$pathId" params={{ pathId: "ground" }} className={className}>
        {body}
      </Link>
    );
  }
  if (latest.kind === "lesson") {
    return (
      <Link to="/lessons/$lessonId" params={{ lessonId: latest.id }} className={className}>
        {body}
      </Link>
    );
  }
  if (latest.kind === "reading") {
    return (
      <Link to="/library/$readingId" params={{ readingId: latest.id }} className={className}>
        {body}
      </Link>
    );
  }
  return (
    <Link to="/practice/$exerciseId" params={{ exerciseId: latest.id }} className={className}>
      {body}
    </Link>
  );
}

function labelFor(kind: "lesson" | "reading" | "exercise", id: string) {
  if (kind === "lesson") return lessonPath(id)?.lesson.title ?? "A lesson";
  if (kind === "reading") return findReading(id)?.title ?? "A reading";
  return findExercise(id)?.title ?? "A practice";
}
