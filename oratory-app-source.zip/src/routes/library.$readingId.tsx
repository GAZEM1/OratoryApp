import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Blocks } from "@/components/blocks";
import { Back, Shell, Title } from "@/components/shell";
import { findReading } from "@/data/library";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/library/$readingId")({ component: ReadingPage });

function ReadingPage() {
  const { readingId } = Route.useParams();
  const reading = findReading(readingId);
  const markReading = useDesk((state) => state.markReading);
  const remember = useDesk((state) => state.remember);
  const done = useDesk((state) => Boolean(state.readings[readingId]));
  const hydrated = useDesk((state) => state.hydrated);

  useEffect(() => {
    if (reading) remember("reading", readingId);
  }, [reading, readingId, remember]);

  if (!reading) {
    return (
      <Shell>
        <Back href="/library" label="The shelf" />
        <Title title="That essay is not on the shelf." />
      </Shell>
    );
  }

  return (
    <Shell>
      <Back href="/library" label="The shelf" />
      <Title kicker={`${reading.shelf} · ${reading.minutes} min`} title={reading.title} />
      <Blocks blocks={reading.blocks} />
      <div className="mt-8 flex max-w-2xl flex-wrap items-center gap-3 border-t border-line pt-6">
        <button type="button" className="h-11 rounded-full bg-copper px-5 text-copper-ink" onClick={() => markReading(reading.id)}>
          {hydrated && done ? "Read again" : "Mark as read"}
        </button>
        {hydrated && done ? <span className="text-sm text-muted">On the record.</span> : null}
      </div>
    </Shell>
  );
}
