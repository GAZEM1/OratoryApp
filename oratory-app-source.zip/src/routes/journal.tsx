import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Title } from "@/components/shell";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/journal")({ component: JournalPage });

function JournalPage() {
  const journal = useDesk((state) => state.journal);
  const hydrated = useDesk((state) => state.hydrated);
  const addJournal = useDesk((state) => state.addJournal);
  const removeJournal = useDesk((state) => state.removeJournal);
  const clearDesk = useDesk((state) => state.clearDesk);
  const markExercise = useDesk((state) => state.markExercise);
  const [condition, setCondition] = useState("");
  const [body, setBody] = useState("");

  function save() {
    if (!body.trim()) return;
    addJournal({ condition, body });
    markExercise("evening-record");
    setCondition("");
    setBody("");
  }

  return (
    <Shell>
      <Title
        kicker="Diary"
        title="What happened, before the story."
        lede="Condition of the body first. Then the practice. Then what actually occurred, including nothing."
      />
      <form
        className="max-w-2xl rounded-2xl border border-line bg-surface p-4"
        onSubmit={(event) => {
          event.preventDefault();
          save();
        }}
      >
        <label className="block text-sm text-muted" htmlFor="condition">
          Sleep, food, health, mood
        </label>
        <input
          id="condition"
          value={condition}
          onChange={(event) => setCondition(event.target.value)}
          className="mt-2 h-12 w-full rounded-xl border border-line bg-raised px-3"
          placeholder="Slept five hours. Irritable. No drink."
        />
        <label className="mt-4 block text-sm text-muted" htmlFor="entry">
          The entry
        </label>
        <textarea
          id="entry"
          value={body}
          onChange={(event) => setBody(event.target.value)}
          rows={6}
          className="mt-2 w-full rounded-xl border border-line bg-raised px-3 py-3"
          placeholder="Did the cross and four pentagrams. Forgot the west name and went back. Room unchanged. Hands cold."
        />
        <button type="submit" className="mt-4 h-11 rounded-full bg-copper px-5 text-copper-ink" disabled={!body.trim()}>
          Save the entry
        </button>
      </form>
      <ul className="mt-6 flex max-w-2xl flex-col gap-3">
        {hydrated && journal.length === 0 ? (
          <li className="text-muted">The diary is blank. One line after practice is enough.</li>
        ) : null}
        {hydrated
          ? journal.map((entry) => (
              <li key={entry.id} className="rounded-2xl border border-line bg-surface px-4 py-4">
                <p className="text-sm text-faint">
                  {new Date(entry.at).toLocaleString("en-NZ", {
                    day: "numeric",
                    month: "short",
                    hour: "numeric",
                    minute: "2-digit",
                  })}
                </p>
                {entry.condition ? <p className="mt-2 text-muted">{entry.condition}</p> : null}
                <p className="mt-2 whitespace-pre-wrap">{entry.body}</p>
                <button type="button" className="mt-3 h-10 text-sm text-faint" onClick={() => removeJournal(entry.id)}>
                  Remove this entry
                </button>
              </li>
            ))
          : null}
      </ul>
      <button
        type="button"
        className="mt-10 h-11 text-sm text-faint"
        onClick={() => {
          if (window.confirm("Clear lessons, practices, sigils, and the diary on this device?")) clearDesk();
        }}
      >
        Clear this desk
      </button>
    </Shell>
  );
}
