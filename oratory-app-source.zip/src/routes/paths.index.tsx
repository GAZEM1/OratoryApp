import { createFileRoute, Link } from "@tanstack/react-router";
import { paths } from "@/data/curriculum";
import { Shell, Title } from "@/components/shell";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/paths/")({ component: PathsPage });

function PathsPage() {
  const lessons = useDesk((state) => state.lessons);
  const hydrated = useDesk((state) => state.hydrated);

  return (
    <Shell>
      <Title
        kicker="Curriculum"
        title="Six paths."
        lede="Start at Ground if you are new to the desk. The others assume you can keep a record and name a model."
      />
      <ul className="grid gap-4 md:grid-cols-2">
        {paths.map((path) => {
          const done = path.lessons.filter((lesson) => lessons[lesson.id]).length;
          return (
            <li key={path.id}>
              <Link to="/paths/$pathId" params={{ pathId: path.id }} className="flex h-full flex-col rounded-2xl border border-line bg-surface p-5">
                <span className="text-xs tracking-widest text-copper uppercase">{path.kicker}</span>
                <span className="mt-2 font-display text-3xl">{path.title}</span>
                <span className="mt-3 text-muted">{path.blurb}</span>
                <span className="mt-4 text-sm text-faint">
                  {hydrated ? `${done} of ${path.lessons.length} studied` : `${path.lessons.length} lessons`}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </Shell>
  );
}
