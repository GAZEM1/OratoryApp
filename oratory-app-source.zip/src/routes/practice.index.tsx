import { createFileRoute, Link } from "@tanstack/react-router";
import { exercises } from "@/data/exercises";
import { Shell, Title } from "@/components/shell";
import { localDay, useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/practice/")({ component: PracticePage });

function PracticePage() {
  const done = useDesk((state) => state.exercises);
  const hydrated = useDesk((state) => state.hydrated);

  return (
    <Shell>
      <Title
        kicker="Practice"
        title="Do the thing, then write it."
        lede="Breath, a scored banishing, a statement of will, sigils, memory cards, and the evening record."
      />
      <ul className="grid gap-3 md:grid-cols-2">
        {exercises.map((exercise) => {
          const at = done[exercise.id];
          const today = hydrated && at && localDay(new Date(at)) === localDay();
          return (
            <li key={exercise.id}>
              <Link
                to="/practice/$exerciseId"
                params={{ exerciseId: exercise.id }}
                className="block h-full rounded-2xl border border-line bg-surface p-5"
              >
                <span className="text-xs tracking-widest text-copper uppercase">{exercise.kicker}</span>
                <span className="mt-2 block font-display text-2xl">{exercise.title}</span>
                <span className="mt-2 block text-muted">{exercise.summary}</span>
                <span className="mt-3 block text-sm text-faint">
                  {exercise.minutes} min
                  {hydrated && at ? ` · Last ${today ? "today" : new Date(at).toLocaleDateString("en-NZ", { day: "numeric", month: "short" })}` : ""}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </Shell>
  );
}
