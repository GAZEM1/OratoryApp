import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PracticeBody } from "@/components/practices";
import { Back, Shell, Title } from "@/components/shell";
import { findExercise } from "@/data/exercises";
import { useDesk } from "@/lib/desk-store";

export const Route = createFileRoute("/practice/$exerciseId")({ component: ExercisePage });

function ExercisePage() {
  const { exerciseId } = Route.useParams();
  const exercise = findExercise(exerciseId);
  const markExercise = useDesk((state) => state.markExercise);
  const remember = useDesk((state) => state.remember);
  const [recorded, setRecorded] = useState(false);

  useEffect(() => {
    if (exercise) remember("exercise", exercise.id);
  }, [exercise, remember]);

  if (!exercise) {
    return (
      <Shell>
        <Back href="/practice" label="All practices" />
        <Title title="That practice is not on the desk." />
      </Shell>
    );
  }

  return (
    <Shell>
      <Back href="/practice" label="All practices" />
      <Title kicker={`${exercise.kicker} · ${exercise.minutes} min`} title={exercise.title} lede={exercise.summary} />
      <PracticeBody
        exercise={exercise}
        onDone={() => {
          markExercise(exercise.id);
          setRecorded(true);
        }}
      />
      {recorded ? (
        <p className="mt-4 max-w-xl text-muted">
          Recorded.{" "}
          <Link to="/journal" className="text-copper underline decoration-line underline-offset-4">
            Add a line to the diary
          </Link>{" "}
          before you explain it to yourself.
        </p>
      ) : null}
      {exercise.lessonId ? (
        <p className="mt-6">
          <Link to="/lessons/$lessonId" params={{ lessonId: exercise.lessonId }} className="text-sm text-muted underline decoration-line underline-offset-4">
            The lesson behind this practice
          </Link>
        </p>
      ) : null}
    </Shell>
  );
}
