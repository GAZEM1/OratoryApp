import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pentagram-1vssK5GR.js
var import_jsx_runtime = require_jsx_runtime();
var ORDER = [
	3,
	0,
	2,
	4,
	1,
	3
];
function vertices(cx, cy, radius) {
	return Array.from({ length: 5 }, (_, index) => {
		const angle = (-90 + index * 72) * Math.PI / 180;
		return {
			x: cx + radius * Math.cos(angle),
			y: cy + radius * Math.sin(angle)
		};
	});
}
function PentagramGuide() {
	const points = vertices(120, 124, 88);
	const d = ORDER.map((index) => points[index]).map((point, index) => `${index === 0 ? "M" : "L"} ${point.x.toFixed(1)} ${point.y.toFixed(1)}`).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "my-6 max-w-sm rounded-2xl border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 240 250",
			className: "w-full",
			role: "img",
			"aria-labelledby": "pentagram-title pentagram-desc",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", {
					id: "pentagram-title",
					children: "Banishing earth pentagram"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("desc", {
					id: "pentagram-desc",
					children: "A point-up pentagram. The banishing stroke starts at the lower left, rises to the top, and continues until it closes."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: points.map((point) => `${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(" "),
					fill: "none",
					stroke: "var(--color-line)",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d,
					fill: "none",
					stroke: "var(--color-copper)",
					strokeWidth: "2.5",
					strokeLinejoin: "round",
					strokeLinecap: "round"
				}),
				[
					{
						n: 2,
						at: 0
					},
					{
						n: 5,
						at: 1
					},
					{
						n: 3,
						at: 2
					},
					{
						n: 1,
						at: 3
					},
					{
						n: 4,
						at: 4
					}
				].map((label) => {
					const point = points[label.at];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: point.x,
						cy: point.y,
						r: "11",
						fill: "var(--color-copper)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: point.x,
						y: point.y + 4,
						textAnchor: "middle",
						fontSize: "12",
						fill: "var(--color-copper-ink)",
						fontFamily: "var(--font-display)",
						children: label.n
					})] }, label.n);
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "text-sm text-muted",
			children: "Banishing earth. Begin at 1, the lower left, and follow the numbers back to the start. The lesser ritual uses this figure at all four quarters."
		})]
	});
}
//#endregion
export { PentagramGuide as t };
