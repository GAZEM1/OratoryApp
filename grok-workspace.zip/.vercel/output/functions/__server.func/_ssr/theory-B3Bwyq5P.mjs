import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell, r as Title } from "./shell-BrWD4Hl0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/theory-B3Bwyq5P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var sephiroth = [
	{
		id: "kether",
		n: 1,
		name: "Kether",
		meaning: "Crown",
		x: 160,
		y: 40,
		planet: "Primum Mobile, later linked with Neptune",
		idea: "Unity before anything splits into two.",
		study: "Sit with one sensation — breath at the nostril — and refuse to narrate it. Kether, in this map, is the moment prior to a story."
	},
	{
		id: "chokmah",
		n: 2,
		name: "Chokmah",
		meaning: "Wisdom",
		x: 258,
		y: 108,
		planet: "The zodiac, later Uranus",
		idea: "The first outward flash. Force without a container yet.",
		study: "Write a want in six words, fast, before you edit it into something polite."
	},
	{
		id: "binah",
		n: 3,
		name: "Binah",
		meaning: "Understanding",
		x: 62,
		y: 108,
		planet: "Saturn",
		idea: "Limit, form, time, the womb that gives the flash an edge.",
		study: "Take yesterday's want and name the constraint that would make it real: an hour, a tool, a boundary."
	},
	{
		id: "chesed",
		n: 4,
		name: "Chesed",
		meaning: "Mercy",
		x: 258,
		y: 214,
		planet: "Jupiter",
		idea: "Expansion, generosity, the lawful building of more.",
		study: "Give something concrete away today — time, a note, a meal — and write what it cost."
	},
	{
		id: "geburah",
		n: 5,
		name: "Geburah",
		meaning: "Severity",
		x: 62,
		y: 214,
		planet: "Mars",
		idea: "Strength as the power to cut, stop, and defend a form.",
		study: "Name one practice you will not do, and the reason. Severity without a reason is just temper."
	},
	{
		id: "tiphareth",
		n: 6,
		name: "Tiphareth",
		meaning: "Beauty",
		x: 160,
		y: 262,
		planet: "The Sun",
		idea: "The center that holds mercy and severity in one working heart.",
		study: "After any exercise, ask: was this balanced enough to repeat tomorrow? Beauty here means coherence, not prettiness."
	},
	{
		id: "netzach",
		n: 7,
		name: "Netzach",
		meaning: "Victory",
		x: 258,
		y: 352,
		planet: "Venus",
		idea: "Desire, rhythm, art, the green persistence of wanting.",
		study: "Make one unnecessary beautiful thing connected to the work: a cleaned altar corner, a careful page, a walked loop."
	},
	{
		id: "hod",
		n: 8,
		name: "Hod",
		meaning: "Splendour",
		x: 62,
		y: 352,
		planet: "Mercury",
		idea: "Language, analysis, names, the mind that can say what happened.",
		study: "Translate one feeling from practice into three plain sentences. If you cannot say it, you do not have it yet."
	},
	{
		id: "yesod",
		n: 9,
		name: "Yesod",
		meaning: "Foundation",
		x: 160,
		y: 430,
		planet: "The Moon",
		idea: "Imagination, dream, the image-store that feeds the body.",
		study: "Before sleep, write one image you intend to remember. In the morning, write what actually came."
	},
	{
		id: "malkuth",
		n: 10,
		name: "Malkuth",
		meaning: "Kingdom",
		x: 160,
		y: 516,
		planet: "Earth",
		idea: "The body, the room, the rent, the result you can point at.",
		study: "End every working by touching the floor, naming the date, and doing one ordinary next thing. Magick that cannot land is a mood."
	}
];
/** Hermetic Golden Dawn paths on the Kircher tree. Letter–card pairings follow the traditional GD order; Crowley later swapped Heh and Tzaddi. */
var treePaths = [
	{
		n: 11,
		letter: "Aleph",
		hebrew: "א",
		card: "The Fool",
		from: "kether",
		to: "chokmah",
		note: "Air. The leap from unity into the first distinction."
	},
	{
		n: 12,
		letter: "Beth",
		hebrew: "ב",
		card: "The Magician",
		from: "kether",
		to: "binah",
		note: "Mercury. Attention that can aim."
	},
	{
		n: 13,
		letter: "Gimel",
		hebrew: "ג",
		card: "The High Priestess",
		from: "kether",
		to: "tiphareth",
		note: "The Moon, on this path. The long road across the abyss, passing Daath."
	},
	{
		n: 14,
		letter: "Daleth",
		hebrew: "ד",
		card: "The Empress",
		from: "chokmah",
		to: "binah",
		note: "Venus. The door between force and form."
	},
	{
		n: 15,
		letter: "Heh",
		hebrew: "ה",
		card: "The Emperor",
		from: "chokmah",
		to: "tiphareth",
		note: "Aries. Ordering fire. Crowley reassigned this letter to The Star."
	},
	{
		n: 16,
		letter: "Vav",
		hebrew: "ו",
		card: "The Hierophant",
		from: "chokmah",
		to: "chesed",
		note: "Taurus. Teaching, transmission, the nail that joins."
	},
	{
		n: 17,
		letter: "Zayin",
		hebrew: "ז",
		card: "The Lovers",
		from: "binah",
		to: "tiphareth",
		note: "Gemini. A choice that is also a sword."
	},
	{
		n: 18,
		letter: "Cheth",
		hebrew: "ח",
		card: "The Chariot",
		from: "binah",
		to: "geburah",
		note: "Cancer. A body that can carry an intention through noise."
	},
	{
		n: 19,
		letter: "Teth",
		hebrew: "ט",
		card: "Strength",
		from: "chesed",
		to: "geburah",
		note: "Leo. Mercy and severity held by the same hands."
	},
	{
		n: 20,
		letter: "Yod",
		hebrew: "י",
		card: "The Hermit",
		from: "chesed",
		to: "tiphareth",
		note: "Virgo. A small light carried on purpose."
	},
	{
		n: 21,
		letter: "Kaph",
		hebrew: "כ",
		card: "The Wheel",
		from: "chesed",
		to: "netzach",
		note: "Jupiter. Cycles, luck, the turn of conditions."
	},
	{
		n: 22,
		letter: "Lamed",
		hebrew: "ל",
		card: "Justice",
		from: "geburah",
		to: "tiphareth",
		note: "Libra. Adjustment. The ox-goad that corrects a course."
	},
	{
		n: 23,
		letter: "Mem",
		hebrew: "מ",
		card: "The Hanged Man",
		from: "geburah",
		to: "hod",
		note: "Water. Suspension, the view from upside down."
	},
	{
		n: 24,
		letter: "Nun",
		hebrew: "נ",
		card: "Death",
		from: "tiphareth",
		to: "netzach",
		note: "Scorpio. What has to rot so something else can move."
	},
	{
		n: 25,
		letter: "Samekh",
		hebrew: "ס",
		card: "Temperance",
		from: "tiphareth",
		to: "yesod",
		note: "Sagittarius. Mixing, the arrow, the tested middle."
	},
	{
		n: 26,
		letter: "Ayin",
		hebrew: "ע",
		card: "The Devil",
		from: "tiphareth",
		to: "hod",
		note: "Capricorn. The chain you can see is a chain you can work."
	},
	{
		n: 27,
		letter: "Peh",
		hebrew: "פ",
		card: "The Tower",
		from: "netzach",
		to: "hod",
		note: "Mars. Speech and structure struck open."
	},
	{
		n: 28,
		letter: "Tzaddi",
		hebrew: "צ",
		card: "The Star",
		from: "netzach",
		to: "yesod",
		note: "Aquarius. Hope after the strike. Crowley reassigned this letter to The Emperor."
	},
	{
		n: 29,
		letter: "Qoph",
		hebrew: "ק",
		card: "The Moon",
		from: "netzach",
		to: "malkuth",
		note: "Pisces. The long instinctive road down into the body."
	},
	{
		n: 30,
		letter: "Resh",
		hebrew: "ר",
		card: "The Sun",
		from: "hod",
		to: "yesod",
		note: "The Sun. Intellect warming the image-world."
	},
	{
		n: 31,
		letter: "Shin",
		hebrew: "ש",
		card: "Judgement",
		from: "hod",
		to: "malkuth",
		note: "Fire. A call that wakes what was lying down."
	},
	{
		n: 32,
		letter: "Tav",
		hebrew: "ת",
		card: "The World",
		from: "yesod",
		to: "malkuth",
		note: "Saturn, and the elements together. The path into the kingdom you can touch."
	}
];
var pillars = [
	{
		name: "Severity",
		side: "Left as you face the diagram",
		sephiroth: "Binah, Geburah, Hod",
		text: "Form, boundary, analysis. The pillar that stops a thing from spilling into everything."
	},
	{
		name: "Mildness",
		side: "The middle",
		sephiroth: "Kether, Tiphareth, Yesod, Malkuth",
		text: "The line of equilibrium. Daath sits on this pillar between Kether and Tiphareth and is not counted as one of the ten."
	},
	{
		name: "Mercy",
		side: "Right as you face the diagram",
		sephiroth: "Chokmah, Chesed, Netzach",
		text: "Force, expansion, desire. The pillar that starts more than it finishes."
	}
];
function sephirahById(id) {
	return sephiroth.find((item) => item.id === id);
}
function TreeMap() {
	const [selected, setSelected] = (0, import_react.useState)("tiphareth");
	const sphere = sephirahById(selected) ?? sephiroth[5];
	const touching = treePaths.filter((path) => path.from === selected || path.to === selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-start gap-6 lg:grid-cols-[minmax(0,280px)_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-line bg-surface p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 320 560",
				className: "mx-auto w-full max-w-xs",
				role: "group",
				"aria-label": "Tree of Life",
				children: [
					treePaths.map((path) => {
						const from = sephirahById(path.from);
						const to = sephirahById(path.to);
						if (!from || !to) return null;
						const hot = path.from === selected || path.to === selected;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: from.x,
							y1: from.y,
							x2: to.x,
							y2: to.y,
							stroke: hot ? "var(--color-copper)" : "var(--color-line)",
							strokeWidth: hot ? 2 : 1
						}, path.n);
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "160",
						y1: "70",
						x2: "160",
						y2: "230",
						stroke: "var(--color-faint)",
						strokeDasharray: "3 6",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "172",
						y: "168",
						fill: "var(--color-faint)",
						fontSize: "11",
						fontFamily: "var(--font-body)",
						children: "Daath"
					}),
					sephiroth.map((item) => {
						const on = item.id === selected;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							role: "button",
							tabIndex: 0,
							"aria-pressed": on,
							"aria-label": `${item.n}. ${item.name}, ${item.meaning}`,
							onClick: () => setSelected(item.id),
							onKeyDown: (event) => {
								if (event.key === "Enter" || event.key === " ") {
									event.preventDefault();
									setSelected(item.id);
								}
							},
							className: "cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: item.x,
								cy: item.y,
								r: "20",
								fill: on ? "var(--color-copper)" : "var(--color-raised)",
								stroke: on ? "var(--color-copper)" : "var(--color-muted)",
								strokeWidth: "1.5"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x: item.x,
								y: item.y + 4,
								textAnchor: "middle",
								fontSize: "13",
								fill: on ? "var(--color-copper-ink)" : "var(--color-fg)",
								fontFamily: "var(--font-display)",
								children: item.n
							})]
						}, item.id);
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-2 pb-2 text-sm text-faint",
				children: "Tap a sphere. Paths in copper touch it."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl border border-line bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs tracking-widest text-copper uppercase",
					children: [
						sphere.n,
						". ",
						sphere.planet
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "mt-2 font-display text-3xl",
					children: [sphere.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-3 text-xl text-muted",
						children: sphere.meaning
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4",
					children: sphere.idea
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: sphere.study
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-6 font-display text-xl",
					children: "Paths that touch it"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: touching.map((path) => {
						const other = sephirahById(path.from === selected ? path.to : path.from);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl border border-line bg-bg px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-copper",
								children: [
									path.n,
									". ",
									path.letter,
									" ",
									path.hebrew,
									" · ",
									path.card
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1",
								children: [
									"Toward ",
									other?.name,
									". ",
									path.note
								]
							})]
						}, path.n);
					})
				})
			]
		})]
	});
}
var QUARTERS = [
	{
		id: "n",
		name: "North",
		element: "Earth",
		angel: "Auriel",
		place: "At your left hand when you face east."
	},
	{
		id: "e",
		name: "East",
		element: "Air",
		angel: "Raphael",
		place: "The direction you face to begin."
	},
	{
		id: "s",
		name: "South",
		element: "Fire",
		angel: "Michael",
		place: "At your right hand when you face east."
	},
	{
		id: "w",
		name: "West",
		element: "Water",
		angel: "Gabriel",
		place: "Behind you when you face east."
	}
];
var MODELS = [
	[
		"Spirit",
		"Persons who are not human",
		"Silence, flattery, obsession",
		"Manners: open, constrain, license to depart"
	],
	[
		"Energy",
		"A charge the body moves",
		"No sleep, fried nerves",
		"Circulate it, then banish"
	],
	[
		"Psychological",
		"Symbol working the operator",
		"A mood mistaken for a message",
		"A diary that can catch you"
	],
	[
		"Information",
		"A compressed instruction",
		"An intent too vague to fail",
		"One falsifiable sentence"
	],
	[
		"Meta",
		"Whichever model you chose on purpose",
		"Switching the story afterward",
		"Write the model before you begin"
	]
];
function TheoryPage() {
	const [quarter, setQuarter] = (0, import_react.useState)("e");
	const active = QUARTERS.find((item) => item.id === quarter) ?? QUARTERS[1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: "Theory",
			title: "Maps, not souvenirs.",
			lede: "The Hermetic tree, the Golden Dawn quarters, and five models you can actually name in a diary."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Tree of Life"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 mb-4 max-w-2xl text-muted",
				children: "Ten sephiroth, twenty-two paths, Golden Dawn letter and tarot pairings. Jewish trees are not identical. Daath is marked and not counted."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeMap, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-3 md:grid-cols-3",
				children: pillars.map((pillar) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-copper uppercase",
							children: pillar.side
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-xl",
							children: pillar.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-faint",
							children: pillar.sephiroth
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: pillar.text
						})
					]
				}, pillar.name))
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Quarters"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: "This is a map with north at the top. In the lodge you face east, so east is in front of you. These are Golden Dawn quarters. Other traditions turn the wheel."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid max-w-md grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuarterButton, {
							id: "n",
							label: "North",
							current: quarter,
							onPick: setQuarter
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuarterButton, {
							id: "w",
							label: "West",
							current: quarter,
							onPick: setQuarter
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid min-h-16 place-items-center rounded-2xl border border-line bg-bg px-2 text-center text-sm text-faint",
							children: "Face east"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuarterButton, {
							id: "e",
							label: "East",
							current: quarter,
							onPick: setQuarter
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuarterButton, {
							id: "s",
							label: "South",
							current: quarter,
							onPick: setQuarter
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "mt-4 max-w-xl rounded-2xl border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-copper uppercase",
							children: active.element
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-3xl",
							children: active.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2",
							children: [active.angel, "."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: active.place
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-12 max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Models"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 mb-4 text-muted",
					children: "Pick one before a working. Write it down. Do not change it after you see the result."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded-2xl border border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-xl text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-raised text-faint",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-semibold",
									children: "Model"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-semibold",
									children: "Change comes from"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-semibold",
									children: "Failure looks like"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-semibold",
									children: "So you"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: MODELS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							className: "border-t border-line bg-surface align-top",
							children: row.map((cell) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-3",
								children: cell
							}, cell))
						}, row[0])) })]
					})
				})
			]
		})
	] });
}
function QuarterButton({ id, label, current, onPick }) {
	const on = id === current;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick: () => onPick(id),
		className: on ? "min-h-16 rounded-2xl bg-copper px-2 text-copper-ink" : "min-h-16 rounded-2xl border border-line bg-surface px-2",
		children: label
	});
}
//#endregion
export { TheoryPage as component };
