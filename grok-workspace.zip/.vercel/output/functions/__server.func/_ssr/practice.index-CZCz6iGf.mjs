import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as localDay, s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title } from "./shell-BrWD4Hl0.mjs";
import { n as exercises } from "./exercises-DXxLx35K.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice.index-CZCz6iGf.js
var import_jsx_runtime = require_jsx_runtime();
function PracticePage() {
	const done = useDesk((state) => state.exercises);
	const hydrated = useDesk((state) => state.hydrated);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
		kicker: "Practice",
		title: "Do the thing, then write it.",
		lede: "Breath, a scored banishing, a statement of will, sigils, memory cards, and the evening record."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-3 md:grid-cols-2",
		children: exercises.map((exercise) => {
			const at = done[exercise.id];
			const today = hydrated && at && localDay(new Date(at)) === localDay();
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/practice/$exerciseId",
				params: { exerciseId: exercise.id },
				className: "block h-full rounded-2xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs tracking-widest text-copper uppercase",
						children: exercise.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block font-display text-2xl",
						children: exercise.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-muted",
						children: exercise.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-3 block text-sm text-faint",
						children: [
							exercise.minutes,
							" min",
							hydrated && at ? ` · Last ${today ? "today" : new Date(at).toLocaleDateString("en-NZ", {
								day: "numeric",
								month: "short"
							})}` : ""
						]
					})
				]
			}) }, exercise.id);
		})
	})] });
}
//#endregion
export { PracticePage as component };
