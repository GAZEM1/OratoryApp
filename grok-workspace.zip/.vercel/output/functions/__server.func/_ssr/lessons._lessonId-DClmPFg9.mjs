import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$7, s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title, t as Back } from "./shell-BrWD4Hl0.mjs";
import { n as lessonPath } from "./curriculum-BPA7o-3g.mjs";
import { r as findExercise } from "./exercises-DXxLx35K.mjs";
import { t as findReading } from "./library-D_qdTrYh.mjs";
import { t as Blocks } from "./blocks-DL2Q4sMn.mjs";
import { t as PentagramGuide } from "./pentagram-1vssK5GR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lessons._lessonId-DClmPFg9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LessonPage() {
	const { lessonId } = Route$7.useParams();
	const found = lessonPath(lessonId);
	const markLesson = useDesk((state) => state.markLesson);
	const remember = useDesk((state) => state.remember);
	const done = useDesk((state) => Boolean(state.lessons[lessonId]));
	const hydrated = useDesk((state) => state.hydrated);
	(0, import_react.useEffect)(() => {
		if (found) remember("lesson", lessonId);
	}, [
		found,
		lessonId,
		remember
	]);
	if (!found) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
		href: "/paths",
		label: "All paths"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, { title: "That lesson is not on the desk." })] });
	const { path, lesson, index } = found;
	const previous = path.lessons[index - 1];
	const next = path.lessons[index + 1];
	const exercise = lesson.exerciseId ? findExercise(lesson.exerciseId) : null;
	const reading = lesson.readingId ? findReading(lesson.readingId) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/paths/$pathId",
			params: { pathId: path.id },
			className: "mb-6 inline-flex h-11 items-center text-sm text-muted hover:text-fg",
			children: path.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: `${path.title} · ${lesson.minutes} min`,
			title: lesson.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blocks, { blocks: lesson.blocks }),
		lesson.diagram === "pentagram" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PentagramGuide, {}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex max-w-2xl flex-col gap-3",
			children: [exercise ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/practice/$exerciseId",
				params: { exerciseId: exercise.id },
				className: "rounded-2xl border border-line bg-raised px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tracking-widest text-copper uppercase",
					children: "Practice"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block font-display text-xl",
					children: exercise.title
				})]
			}) : null, reading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/library/$readingId",
				params: { readingId: reading.id },
				className: "text-copper underline decoration-line underline-offset-4",
				children: ["Further reading: ", reading.title]
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex max-w-2xl flex-wrap items-center gap-3 border-t border-line pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-full bg-copper px-5 text-copper-ink",
					onClick: () => markLesson(lesson.id),
					children: hydrated && done ? "Studied again" : "Mark as studied"
				}),
				hydrated && done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: "On the record."
				}) : null,
				previous ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/lessons/$lessonId",
					params: { lessonId: previous.id },
					className: "inline-flex h-11 items-center text-sm text-muted",
					children: "Previous"
				}) : null,
				next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/lessons/$lessonId",
					params: { lessonId: next.id },
					className: "inline-flex h-11 items-center text-sm text-muted",
					children: "Next"
				}) : null
			]
		})
	] });
}
//#endregion
export { LessonPage as component };
