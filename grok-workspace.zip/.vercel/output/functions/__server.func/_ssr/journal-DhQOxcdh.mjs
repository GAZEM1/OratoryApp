import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title } from "./shell-BrWD4Hl0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-DhQOxcdh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function JournalPage() {
	const journal = useDesk((state) => state.journal);
	const hydrated = useDesk((state) => state.hydrated);
	const addJournal = useDesk((state) => state.addJournal);
	const removeJournal = useDesk((state) => state.removeJournal);
	const clearDesk = useDesk((state) => state.clearDesk);
	const markExercise = useDesk((state) => state.markExercise);
	const [condition, setCondition] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	function save() {
		if (!body.trim()) return;
		addJournal({
			condition,
			body
		});
		markExercise("evening-record");
		setCondition("");
		setBody("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: "Diary",
			title: "What happened, before the story.",
			lede: "Condition of the body first. Then the practice. Then what actually occurred, including nothing."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "max-w-2xl rounded-2xl border border-line bg-surface p-4",
			onSubmit: (event) => {
				event.preventDefault();
				save();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-sm text-muted",
					htmlFor: "condition",
					children: "Sleep, food, health, mood"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "condition",
					value: condition,
					onChange: (event) => setCondition(event.target.value),
					className: "mt-2 h-12 w-full rounded-xl border border-line bg-raised px-3",
					placeholder: "Slept five hours. Irritable. No drink."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-4 block text-sm text-muted",
					htmlFor: "entry",
					children: "The entry"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: "entry",
					value: body,
					onChange: (event) => setBody(event.target.value),
					rows: 6,
					className: "mt-2 w-full rounded-xl border border-line bg-raised px-3 py-3",
					placeholder: "Did the cross and four pentagrams. Forgot the west name and went back. Room unchanged. Hands cold."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "mt-4 h-11 rounded-full bg-copper px-5 text-copper-ink",
					disabled: !body.trim(),
					children: "Save the entry"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-6 flex max-w-2xl flex-col gap-3",
			children: [hydrated && journal.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-muted",
				children: "The diary is blank. One line after practice is enough."
			}) : null, hydrated ? journal.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl border border-line bg-surface px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-faint",
						children: new Date(entry.at).toLocaleString("en-NZ", {
							day: "numeric",
							month: "short",
							hour: "numeric",
							minute: "2-digit"
						})
					}),
					entry.condition ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: entry.condition
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 whitespace-pre-wrap",
						children: entry.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 h-10 text-sm text-faint",
						onClick: () => removeJournal(entry.id),
						children: "Remove this entry"
					})
				]
			}, entry.id)) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-10 h-11 text-sm text-faint",
			onClick: () => {
				if (window.confirm("Clear lessons, practices, sigils, and the diary on this device?")) clearDesk();
			},
			children: "Clear this desk"
		})
	] });
}
//#endregion
export { JournalPage as component };
