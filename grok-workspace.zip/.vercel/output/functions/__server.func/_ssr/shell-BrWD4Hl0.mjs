import { S as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as House, i as Library, n as Route, o as Flame, r as PenLine, s as BookOpen } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-BrWD4Hl0.js
var import_jsx_runtime = require_jsx_runtime();
var NAV = [
	{
		href: "/",
		label: "Desk",
		long: "Desk",
		icon: House
	},
	{
		href: "/paths",
		label: "Paths",
		long: "Paths",
		icon: Route
	},
	{
		href: "/library",
		label: "Read",
		long: "Library",
		icon: Library
	},
	{
		href: "/practice",
		label: "Work",
		long: "Practice",
		icon: Flame
	},
	{
		href: "/journal",
		label: "Log",
		long: "Diary",
		icon: PenLine
	}
];
function active(path, href) {
	if (href === "/") return path === "/";
	return path === href || path.startsWith(`${href}/`);
}
function Shell({ children }) {
	const path = useRouterState({ select: (state) => state.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-6xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-r border-line px-5 py-7 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-xl bg-copper font-display text-lg text-copper-ink",
							children: "O"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-xl leading-none",
							children: "Oratory"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs tracking-widest text-faint uppercase",
							children: "Study desk"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "mt-10 flex flex-col gap-1",
						children: [NAV.map((item) => {
							const on = active(path, item.href);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.href,
								className: on ? "flex h-11 items-center gap-3 rounded-xl bg-raised px-3 text-fg" : "flex h-11 items-center gap-3 rounded-xl px-3 text-muted hover:bg-surface hover:text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									"aria-hidden": true
								}), item.long]
							}, item.href);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/theory",
							className: active(path, "/theory") ? "mt-2 flex h-11 items-center gap-3 rounded-xl bg-raised px-3 text-fg" : "mt-2 flex h-11 items-center gap-3 rounded-xl px-3 text-muted hover:bg-surface hover:text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
								className: "size-4",
								"aria-hidden": true
							}), "Theory"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto text-sm text-faint",
						children: "Notes for study. Not a lineage, and not medicine."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-w-0 flex-1 px-4 pt-6 pb-28 md:px-8 md:pt-8 md:pb-16",
				children
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mx-auto grid max-w-lg grid-cols-5",
				children: NAV.map((item) => {
					const on = active(path, item.href);
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.href,
						className: on ? "flex h-16 flex-col items-center justify-center gap-1 text-copper" : "flex h-16 flex-col items-center justify-center gap-1 text-faint",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs",
							children: item.label
						})]
					}) }, item.href);
				})
			})
		})]
	});
}
function Title({ kicker, title, lede }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-8 max-w-2xl",
		children: [
			kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs tracking-widest text-copper uppercase",
				children: kicker
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl leading-tight text-fg md:text-4xl",
				children: title
			}),
			lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: lede
			}) : null
		]
	});
}
function Back({ href, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: href,
		className: "mb-6 inline-flex h-11 items-center text-sm text-muted hover:text-fg",
		children: label
	});
}
//#endregion
export { Shell as n, Title as r, Back as t };
