//#region node_modules/.nitro/vite/services/ssr/assets/library-D_qdTrYh.js
var readings = [
	{
		id: "magical-diary",
		title: "How to keep a magical diary",
		minutes: 8,
		shelf: "Method",
		blocks: [
			{
				type: "p",
				text: "The diary is older than any one order, but the Golden Dawn made it law for a reason the order's later readers still underuse. A magical event that is not written down within the hour becomes a story. Stories improve themselves. Pages do not, unless you help them cheat."
			},
			{
				type: "h",
				text: "The heading is the body"
			},
			{
				type: "p",
				text: "Start with sleep, food, and whether you are medicated, drunk, ill, or furious. The Golden Dawn adepts were told to note the condition of the body because ritual states are physical states. A vision on four hours of sleep is data about sleep until proven otherwise. Write the condition before the poetry. If you are embarrassed to write it, that embarrassment is part of the condition."
			},
			{
				type: "h",
				text: "Separate observation from gloss"
			},
			{
				type: "p",
				text: "Use two beats. First: what the senses had. 'The candle leaned, my hands were cold, I forgot the west name and went back.' Second, marked as gloss: 'I think the cold was the water quarter.' If you only write the gloss, a month from now you will not be able to audit yourself. You will only have a theology."
			},
			{
				type: "p",
				text: "Review on Saturn's day. Read the week in one sitting. Count how many entries name a practice, and how many are only mood. Cut one thing that looked like work and was only costume. Planning is a ritual if you do it on the page and then obey it."
			},
			{
				type: "link",
				href: "/journal",
				label: "Open the diary"
			}
		]
	},
	{
		id: "kybalion",
		title: "The Kybalion is a modern book",
		minutes: 9,
		shelf: "Sources",
		blocks: [
			{
				type: "p",
				text: "In 1908 a small book called The Kybalion appeared in Chicago, attributed to Three Initiates. The prose, the publisher, and the ideas line up with William Walker Atkinson, who wrote a great deal of New Thought under his own name and under masks. New Thought held that mind is the primary craft material of a life. The Kybalion dresses that claim in a Hermetic costume and offers seven principles."
			},
			{
				type: "p",
				text: "You should know this before you memorize the principles, not after. The Corpus Hermeticum is a different library: Greek texts from late antiquity, philosophical, often pious, not a list of seven laws for winning. The Emerald Tablet is a different scrap again. If a teacher says the Kybalion is what the priests of Egypt whispered, they have not checked, or they prefer the whisper."
			},
			{
				type: "h",
				text: "What is still worth taking"
			},
			{
				type: "p",
				text: "Correspondence trains you to move between scales on purpose. Polarity and rhythm stop you treating a mood as an identity: the opposite quality is on the same stick, and the stick swings. Cause and effect, read humbly, is an instruction to look for mechanisms instead of auras first. Vibration is the least precise of the seven and the easiest to fake; do not build a metaphysics on a metaphor about rates unless you can say what is vibrating."
			},
			{
				type: "p",
				text: "Gender, as Atkinson uses it, is a cosmic polarity he calls masculine and feminine. It is a period piece. It is a bad tool for thinking about anyone's actual body or rank. Leave it in 1908 unless you are writing a history essay."
			},
			{
				type: "note",
				tone: "source",
				title: "Read it in an afternoon",
				text: "The book is short and, in the United States, public domain. Read it once with the date written at the top of your notes. Then read a real Hermetic text — a translation of the Corpus, or the Tablet — and notice the difference in temperature."
			}
		]
	},
	{
		id: "emerald-tablet",
		title: "The Emerald Tablet, in plain speech",
		minutes: 7,
		shelf: "Sources",
		blocks: [
			{
				type: "p",
				text: "What circulates under the name of the Emerald Tablet is a brief alchemical sermon. Its oldest surviving forms are Arabic, then Latin. The famous English compression — as above, so below — is a fair report of one sentence and a poor report of the whole. The text also talks about a single work, a mediation between sun and moon, a separation and a recombination, and the operator's role in carrying that process through. It is alchemy's voice, not a self-help couplet."
			},
			{
				type: "p",
				text: "For a student of ritual the useful extraction is this. Symbol systems are ladders between scales. A planet, a day, a metal, a mood, a sephirah: the art claims these scales comment on each other. Your job is to learn the comments well enough to design a coherent rite, and to notice when a 'correspondence' is just a pun. The Tablet is not a permission slip to ignore the scale that has a receipt attached — money, health, the law, other people's consent."
			},
			{
				type: "quote",
				text: "That which is above is from that which is below, and that which is below is from that which is above, working the miracles of one.",
				cite: "A plain rendering of the Tablet's best-known line, not a sacred original"
			}
		]
	},
	{
		id: "spare-alphabet",
		title: "Sigils, from the alphabet onward",
		minutes: 8,
		shelf: "Chaos",
		blocks: [
			{
				type: "p",
				text: "Austin Osman Spare treated desire as something the conscious sentence botches. His practical method, taught in countless later variants, runs like this. Write what you want in a sentence that is already true in its grammar: present, simple, about your own action or state. Remove the vowels. Remove any consonant that has already appeared. What remains is a small alphabet that does not look like the request. Combine those letters into one mark. Stare, chant, gasp, or go empty until the mark is charged and the sentence is hard to recall. Put the paper away."
			},
			{
				type: "p",
				text: "The later chaos books added slogans. Lust of result is the one students quote and then violate by checking the sigil every hour. Spare's point is not that wanting is vulgar. It is that hovering over the open grave of a wish keeps it in the part of the mind that argues. Delegation includes leaving it alone. Set a date to look. Do not peek."
			},
			{
				type: "h",
				text: "A sentence that can survive the method"
			},
			{
				type: "steps",
				items: [
					"One change, not a stack.",
					"Present tense. 'I sleep until morning' rather than 'I will try to sleep better.'",
					"No negation. The alphabet method cannot see the word not; the picture-making mind tends to keep the thing you named.",
					"No other person's will in the sentence.",
					"A way to know, later, whether it happened."
				]
			},
			{
				type: "link",
				href: "/practice/sigil-atelier",
				label: "Build one on the sigil bench"
			}
		]
	},
	{
		id: "why-banish",
		title: "What a banishing is for",
		minutes: 8,
		shelf: "Ritual",
		blocks: [
			{
				type: "p",
				text: "Beginners hear 'banishing' and picture a fight. In the Golden Dawn's daily use the Lesser Banishing Ritual of the Pentagram is closer to washing your hands and locking the door. You mark a space. You put your attention at the four quarters in a fixed order. You state names you had to memorize. You close by returning to the cross. The room may feel different. The reliable result, at first, is that you can do a complete symbolic act without drifting into a speech."
			},
			{
				type: "p",
				text: "There is a second use, and it is the one that saves people. After a working, after a nightmare, after a book that left you porous, the same ritual is a way to end. Spirits, if you are working in that model, are dismissed. In the psychological model, you are dismissing a state. Either way, the license to leave matters more than the invitation. Students who only know how to open become weather vanes."
			},
			{
				type: "p",
				text: "Do not use a banishing as a substitute for a lock, a doctor, or an honest conversation. A ritual that clears a room does not clear a person who is hurting you, and it does not treat an illness. Use it for what it is: a form that begins and ends, practiced until the form is in the body."
			},
			{
				type: "link",
				href: "/lessons/lbrp-study",
				label: "Study the score"
			}
		]
	},
	{
		id: "column-of-attention",
		title: "A column of attention",
		minutes: 8,
		shelf: "Ritual",
		blocks: [
			{
				type: "p",
				text: "Lodges teach a rite often called the Middle Pillar: divine names vibrated at points along the body's center line, with the breath circulating light through the sphere of sensation. Israel Regardie's written version is the one most people meet, and it is his prose, not a script to paste around. What follows is a plain study practice in the same family. It is not a transcription."
			},
			{
				type: "steps",
				items: [
					"Stand or sit facing east. Three even breaths. The Qabalistic cross, if you know it.",
					"At the crown, a point of white. On the exhale, a long vowel hum, quiet. Feel the point, do not decorate it.",
					"At the throat, a second point. The same hum. Then the heart. Then the groin. Then the soles, as if the column continued into the floor.",
					"Inhale from the floor to the crown, slowly. Exhale from the crown back down. Four circuits.",
					"Cross again, or simply feel the chair. Write whether you got drowsy, emotional, or bored. All three are normal."
				]
			},
			{
				type: "p",
				text: "If names help you, use the ones you are actually studying — Eheieh at the crown is the traditional association with Kether — but do not collect extra words you cannot yet place on the tree. A column you can feel is worth more than a column you can footnote."
			},
			{
				type: "note",
				tone: "caution",
				title: "Stop if the body revolts",
				text: "Dizziness, a racing heart, or a sense that you are not in the room are reasons to open your eyes, feel your feet, and eat something. Intensity is not the grading rubric."
			}
		]
	},
	{
		id: "two-doors",
		title: "Gnosis: two doors",
		minutes: 7,
		shelf: "Chaos",
		blocks: [
			{
				type: "p",
				text: "The word gnosis just means knowledge, and in older religion it often means a saving knowledge of God. Chaos magick narrowed it to a technique: a short interruption of ordinary self-talk, used to launch a sigil or to hear what a rite is actually doing. You do not need the theology to use the technique. You do need to notice that the same word covers both, so a forum post and a late-antique sermon are not talking about one thing."
			},
			{
				type: "p",
				text: "The inhibitory door is silence that gets deeper than relaxation content. You are not managing a fantasy. You are letting the manager clock out. The excitatory door is the opposite excess: drum, dance, gasp, spin, a single shouted vowel, until the commentary cannot keep up. Sex and strong drugs appear in the literature as excitatory methods. They also wreck the variable you are trying to study, because you cannot tell the rite from the substance, and they are outside this desk."
			},
			{
				type: "p",
				text: "Pick one door and keep it for a fortnight. The sign that you have touched gnosis, rather than merely performed a wellness routine, is embarrassingly small. The sentence you meant to think next is gone. The mark in your hand looks like itself and not like a request. Then you stop. Gnosis held open on purpose turns into dissociation. The door is a door because you pass through and come back."
			}
		]
	},
	{
		id: "servitors",
		title: "Servitors as designed habits",
		minutes: 8,
		shelf: "Chaos",
		blocks: [
			{
				type: "p",
				text: "Thoughtforms, artificial elementals, servitors: the names shift and the worksheet barely does. You create a limited agent. You give it a sign, a feeding schedule, a job, and a death. In a spirit model you are making a small spirit. In a psychological model you are giving a sub-routine a mask so your conscience will stop micromanaging it. Write down which model you are in. Do not discover the model afterward, when you need the result to count."
			},
			{
				type: "h",
				text: "The design that does not become a haunt"
			},
			{
				type: "p",
				text: "One job, phrased as a behavior you can see. A name you do not say at the shop. A sign simple enough to redraw from memory. Food: a defined glance, not 'whenever I think of it,' because that is grazing. A term of thirty days. A sentence of dismissal you write on the same page as the birth, so you are not inventing an exorcism in a panic. At the end of the term, dismiss it even if you liked it. You can make it again on purpose. Accidental immortality is just an obsession with stationery."
			},
			{
				type: "note",
				tone: "caution",
				title: "Nothing that aims at another person",
				text: "A servitor sent to change someone else's feelings is the coercive operation you already decided not to train. It also trains you to outsource your own conversations. Give it work inside your conduct."
			}
		]
	},
	{
		id: "planetary-week",
		title: "A planetary week you can keep",
		minutes: 6,
		shelf: "Practice",
		blocks: [
			{
				type: "p",
				text: "Planetary hours are a finer grid: each day divided by the old Chaldean order, sunrise to sunset. They are worth learning when the week itself is already in your hands. Until then the day is the unit. The ruler of the day is the planet whose name the day still wears in several European languages, English included."
			},
			{
				type: "steps",
				items: [
					"Sunday, the Sun. Center, display, the heart of a thing. Do the cross or sit.",
					"Monday, the Moon. Reception, dream, memory. Write an image.",
					"Tuesday, Mars. Severance and courage. A boundary, or the pentagram rite.",
					"Wednesday, Mercury. Speech and sorting. Cards, notes, a letter you actually send.",
					"Thursday, Jupiter. Increase through law, study, generosity. Read a chapter. Give something.",
					"Friday, Venus. Attraction and repair. Make the place of practice fit to be seen.",
					"Saturday, Saturn. Limit, review, the long clock. Read the diary. Remove one excess."
				]
			},
			{
				type: "p",
				text: "If you miss a day, do not stack it onto the next morning out of guilt. Saturn's lesson is already that time is not negotiable. Pick up the day you are actually in."
			}
		]
	},
	{
		id: "results-and-doubt",
		title: "Results, doubt, and the record",
		minutes: 8,
		shelf: "Method",
		blocks: [
			{
				type: "p",
				text: "Magick that cannot fail is not a practice. It is a story with a costume. Decide, before the working, what the world would look like if it worked, and what it would look like if it did not. Write both. 'I will be more open to signs' is not a result. 'I hand in the form before Friday' is a result. 'I sleep five nights without waking in a panic' is a result. Omens can sit in a third column. They do not get to replace the first one."
			},
			{
				type: "p",
				text: "Doubt is not the enemy of the art. Unrecorded doubt is. If you only write the hits, you will become a person who cannot be corrected, which is the opposite of an initiate in any order worth the name. Once a week, count attempts and hits without explaining them away. If a class of working never hits, retire it for a season. Loyalty to a technique you invented last month is not piety."
			},
			{
				type: "p",
				text: "There is a kind of result that is not the petition. You are less of a liar. You can sit still. You can close what you open. You know the tree well enough to find Tiphareth without counting on your fingers. Count those. They are the results that make the stranger ones interpretable. A vision in a life with no craft is just a night."
			}
		]
	},
	{
		id: "a-shelf",
		title: "A shelf: what to read next",
		minutes: 9,
		shelf: "Sources",
		blocks: [
			{
				type: "p",
				text: "Start with books you can meet in full, not with threads about books. A public library and a second-hand shop will do more than another tab. The list below is a path through the material this desk is built from. It is not a canon you must swear to. Read with a pencil, and keep the diary open beside the book so the book has to survive contact with your actual week."
			},
			{
				type: "h",
				text: "Public domain, or old enough to find in free scholarly editions"
			},
			{
				type: "steps",
				items: [
					"The Kybalion (1908), once, with the date in the margin. Then stop treating it as antiquity.",
					"A translation of the Emerald Tablet, any honest short one, read next to a page of commentary that admits the Arabic source.",
					"The Corpus Hermeticum, in a modern scholarly translation if you can borrow it. Different temperature, older.",
					"Heinrich Cornelius Agrippa, Three Books of Occult Philosophy. Use it as an encyclopedia of Renaissance correspondences, not as a nightstand breviary. Skim, then camp in one chapter.",
					"The Sefer Yetzirah, any annotated translation that shows you the three mothers, seven doubles, and twelve simples.",
					"S. L. MacGregor Mathers' introduction and translation work around Kabbalah Unveiled, understanding it is a Victorian doorway into the Zohar, not the Zohar itself."
				]
			},
			{
				type: "h",
				text: "Still in copyright: borrow them"
			},
			{
				type: "steps",
				items: [
					"Israel Regardie, The Golden Dawn, when you want the lodge papers in one brick. Read the knowledge lectures before the rituals.",
					"Lon Milo DuQuette, The Chicken Qabalah, if the tree is still a poster to you. He is irreverent and unusually clear.",
					"Peter J. Carroll, Liber Null & Psychonaut, for the chaos current in its hard early form. Argue with it in the margin.",
					"Phil Hine, Condensed Chaos, if Carroll's tone locks you out. Same current, more humane pacing.",
					"A real history beside the how-to. Something like Owen Davies on grimoires, or a serious introduction to Kabbalah by a scholar of Judaism, so the borrowing stays visible."
				]
			},
			{
				type: "note",
				tone: "caution",
				title: "Own your copies honestly",
				text: "Pirated ritual books teach you to treat the art as loot. Save up, borrow, or read what is actually free. The tradition is already full of forged title pages. You do not need to add a forged file."
			},
			{
				type: "p",
				text: "When you finish a book, write a half page: what it thinks magick is, what it wants you to do every day, and what you refuse. That half page is worth more than a shelf you have only photographed."
			}
		]
	}
];
function findReading(id) {
	return readings.find((reading) => reading.id === id) ?? null;
}
//#endregion
export { readings as n, findReading as t };
