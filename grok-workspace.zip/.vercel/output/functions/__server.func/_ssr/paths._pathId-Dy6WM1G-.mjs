import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Route$3, s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title, t as Back } from "./shell-BrWD4Hl0.mjs";
import { r as paths } from "./curriculum-BPA7o-3g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/paths._pathId-Dy6WM1G-.js
var import_jsx_runtime = require_jsx_runtime();
function PathPage() {
	const { pathId } = Route$3.useParams();
	const path = paths.find((item) => item.id === pathId);
	const lessons = useDesk((state) => state.lessons);
	const hydrated = useDesk((state) => state.hydrated);
	if (!path) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
		href: "/paths",
		label: "All paths"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, { title: "That path is not on the desk." })] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
			href: "/paths",
			label: "All paths"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: path.kicker,
			title: path.title,
			lede: path.blurb
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex max-w-2xl flex-col gap-3",
			children: path.lessons.map((lesson, index) => {
				const done = hydrated && lessons[lesson.id];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/lessons/$lessonId",
					params: { lessonId: lesson.id },
					className: "flex items-baseline justify-between gap-4 rounded-2xl border border-line bg-surface px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-3 font-display text-copper",
							children: index + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl",
							children: lesson.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block pl-7 text-sm text-faint",
							children: [lesson.minutes, " min"]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-sm text-muted",
						children: done ? "Studied" : "Open"
					})]
				}) }, lesson.id);
			})
		})
	] });
}
//#endregion
export { PathPage as component };
