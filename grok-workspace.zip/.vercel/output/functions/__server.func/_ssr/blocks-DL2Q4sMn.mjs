import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blocks-DL2Q4sMn.js
var import_jsx_runtime = require_jsx_runtime();
function Blocks({ blocks }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex max-w-2xl flex-col gap-4",
		children: blocks.map((block, index) => {
			if (block.type === "h") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 font-display text-2xl text-fg",
				children: block.text
			}, index);
			if (block.type === "quote") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
				className: "border-l-2 border-copper pl-4 text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl leading-snug",
					children: block.text
				}), block.cite ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "mt-2 text-sm text-faint",
					children: block.cite
				}) : null]
			}, index);
			if (block.type === "steps") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-3",
				children: block.items.map((item, step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3 rounded-2xl border border-line bg-surface px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-copper",
						children: step + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
				}, step))
			}, index);
			if (block.type === "note") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rounded-2xl border border-line bg-raised px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-copper uppercase",
					children: block.title ?? (block.tone === "caution" ? "Care" : "Source")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: block.text
				})]
			}, index);
			if (block.type === "link") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: block.href,
				className: "text-copper underline decoration-line underline-offset-4",
				children: block.label
			}) }, index);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: block.text }, index);
		})
	});
}
//#endregion
export { Blocks as t };
