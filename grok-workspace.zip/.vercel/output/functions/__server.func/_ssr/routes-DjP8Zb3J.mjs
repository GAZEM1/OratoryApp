import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title } from "./shell-BrWD4Hl0.mjs";
import { n as lessonPath, r as paths, t as lessonCount } from "./curriculum-BPA7o-3g.mjs";
import { n as exercises, r as findExercise, t as exerciseForDate } from "./exercises-DXxLx35K.mjs";
import { n as readings, t as findReading } from "./library-D_qdTrYh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DjP8Zb3J.js
var import_jsx_runtime = require_jsx_runtime();
var PROMPTS = [
	"Write the change you want in one sentence. Cut every word that is not the change.",
	"Name the model you are using today: spirit, energy, psyche, information, or undecided.",
	"Face your chosen east wall and do the cross once, even if you remember only the gestures.",
	"Read one page and write what it wants you to do before the next meal.",
	"Record the condition of the body before you record the vision.",
	"Pick one sephirah and live in it for an hour. Say which one.",
	"If a working has no close, it is not finished. Close something you opened.",
	"Make the sigil, then put it where you will not check it.",
	"Saturn's question: what are you calling practice that is only costume?",
	"Translate a symbol into three plain sentences. If you cannot, you do not have it yet.",
	"Give the week its planet. Do one act in that style and write the line.",
	"Boredom is a result. Write it with the same pen you would use for a vision.",
	"Outline a ritual's bones: open, declare, operate, close, record. Do not perform a new one.",
	"After the work, do one ordinary next thing. Magick that cannot land is a mood."
];
function Desk() {
	const hydrated = useDesk((state) => state.hydrated);
	const lessons = useDesk((state) => state.lessons);
	const readingsDone = useDesk((state) => state.readings);
	const exerciseMap = useDesk((state) => state.exercises);
	const recent = useDesk((state) => state.recent);
	const streak = useDesk((state) => state.streak);
	const journal = useDesk((state) => state.journal);
	const today = /* @__PURE__ */ new Date();
	const prompt = PROMPTS[dayOfYear(today) % PROMPTS.length];
	const suggested = exerciseForDate(today);
	const latest = recent[0];
	const studied = Object.keys(lessons).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: "Oratory",
			title: "The desk is open.",
			lede: "Reading, theory, and practice for the study of magick. The record stays on this device."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-6 max-w-2xl text-muted",
			suppressHydrationWarning: true,
			children: [
				today.toLocaleDateString("en-NZ", {
					weekday: "long",
					day: "numeric",
					month: "long"
				}),
				". ",
				prompt
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-4 lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContinueCard, {
					latest: hydrated ? latest : void 0,
					studied: hydrated ? studied : null
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line bg-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Paths"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/paths",
							className: "text-sm text-copper",
							children: "All paths"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-3",
						children: paths.map((path) => {
							const done = path.lessons.filter((lesson) => lessons[lesson.id]).length;
							const width = `${Math.round(done / path.lessons.length * 100)}%`;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/paths/$pathId",
								params: { pathId: path.id },
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-xl",
										children: path.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-faint",
										children: hydrated ? `${done}/${path.lessons.length}` : "—"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block h-1 rounded-full bg-raised",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block h-1 rounded-full bg-copper",
										style: { width: hydrated ? width : "0%" }
									})
								})]
							}) }, path.id);
						})
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/practice/$exerciseId",
						params: { exerciseId: suggested.id },
						className: "rounded-2xl border border-line bg-raised p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-copper uppercase",
								children: "Today's work"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-2xl",
								children: suggested.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: suggested.summary
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-line bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-faint uppercase",
								children: "Days kept"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-4xl",
								children: hydrated ? streak : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: hydrated ? `${Object.keys(readingsDone).length} readings · ${Object.keys(exerciseMap).length} practices` : "Record opens on this device."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/journal",
						className: "rounded-2xl border border-line bg-surface p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-faint uppercase",
							children: "Diary"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: hydrated && journal[0] ? journal[0].body.slice(0, 140) : "One line after practice is enough. Start with the condition of the body."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/theory",
						className: "rounded-2xl border border-line bg-surface p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-faint uppercase",
							children: "Theory desk"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-xl",
							children: "Tree, quarters, models"
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-8 max-w-2xl text-sm text-faint",
			children: [
				exercises.length,
				" practices and ",
				readings.length,
				" essays are on the desk. Study notes, not an initiation, and not a substitute for medical care."
			]
		})
	] });
}
function dayOfYear(date) {
	const start = new Date(date.getFullYear(), 0, 0);
	return Math.floor((date.getTime() - start.getTime()) / 864e5);
}
function ContinueCard({ latest, studied }) {
	const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-widest text-copper uppercase",
			children: "Continue"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-2xl",
			children: latest ? labelFor(latest.kind, latest.id) : "Start with Ground"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: studied === null ? "Opening your record." : `${studied} of ${lessonCount()} lessons on the record.`
		})
	] });
	const className = "block rounded-2xl border border-line bg-surface p-5";
	if (!latest) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/paths/$pathId",
		params: { pathId: "ground" },
		className,
		children: body
	});
	if (latest.kind === "lesson") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/lessons/$lessonId",
		params: { lessonId: latest.id },
		className,
		children: body
	});
	if (latest.kind === "reading") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/library/$readingId",
		params: { readingId: latest.id },
		className,
		children: body
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/practice/$exerciseId",
		params: { exerciseId: latest.id },
		className,
		children: body
	});
}
function labelFor(kind, id) {
	if (kind === "lesson") return lessonPath(id)?.lesson.title ?? "A lesson";
	if (kind === "reading") return findReading(id)?.title ?? "A reading";
	return findExercise(id)?.title ?? "A practice";
}
//#endregion
export { Desk as component };
