import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title } from "./shell-BrWD4Hl0.mjs";
import { r as paths } from "./curriculum-BPA7o-3g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/paths.index-bSHurOG1.js
var import_jsx_runtime = require_jsx_runtime();
function PathsPage() {
	const lessons = useDesk((state) => state.lessons);
	const hydrated = useDesk((state) => state.hydrated);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
		kicker: "Curriculum",
		title: "Six paths.",
		lede: "Start at Ground if you are new to the desk. The others assume you can keep a record and name a model."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-4 md:grid-cols-2",
		children: paths.map((path) => {
			const done = path.lessons.filter((lesson) => lessons[lesson.id]).length;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/paths/$pathId",
				params: { pathId: path.id },
				className: "flex h-full flex-col rounded-2xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs tracking-widest text-copper uppercase",
						children: path.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 font-display text-3xl",
						children: path.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-3 text-muted",
						children: path.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-4 text-sm text-faint",
						children: hydrated ? `${done} of ${path.lessons.length} studied` : `${path.lessons.length} lessons`
					})
				]
			}) }, path.id);
		})
	})] });
}
//#endregion
export { PathsPage as component };
