import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title } from "./shell-BrWD4Hl0.mjs";
import { n as readings } from "./library-D_qdTrYh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library.index-BEbABiI9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LibraryPage() {
	const [query, setQuery] = (0, import_react.useState)("");
	const done = useDesk((state) => state.readings);
	const hydrated = useDesk((state) => state.hydrated);
	const filtered = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		if (!needle) return readings;
		return readings.filter((reading) => `${reading.title} ${reading.shelf}`.toLowerCase().includes(needle));
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: "Library",
			title: "The shelf.",
			lede: "Essays written for this desk. Dates, lineages, and arguments stay attached to the ideas."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mb-5 block max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Search the shelf"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Search titles",
				className: "h-12 w-full rounded-full border border-line bg-surface px-4"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-3 md:grid-cols-2",
			children: filtered.map((reading) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/library/$readingId",
				params: { readingId: reading.id },
				className: "block h-full rounded-2xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs tracking-widest text-copper uppercase",
						children: reading.shelf
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block font-display text-2xl",
						children: reading.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-3 block text-sm text-faint",
						children: [
							reading.minutes,
							" min",
							hydrated && done[reading.id] ? " · Read" : ""
						]
					})
				]
			}) }, reading.id))
		}),
		filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-muted",
			children: "Nothing on the shelf matches that."
		}) : null
	] });
}
//#endregion
export { LibraryPage as component };
