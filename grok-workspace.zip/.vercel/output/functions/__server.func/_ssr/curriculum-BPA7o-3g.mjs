//#region node_modules/.nitro/vite/services/ssr/assets/curriculum-BPA7o-3g.js
var paths = [
	{
		id: "ground",
		title: "Ground",
		kicker: "Before the symbols",
		blurb: "Definitions you can test, five models, the diary, and the limits that keep the work inside a life.",
		lessons: [
			{
				id: "what-magick-is",
				title: "A definition you can test",
				minutes: 8,
				readingId: "results-and-doubt",
				blocks: [
					{
						type: "quote",
						text: "Magick is the Science and Art of causing Change to occur in conformity with Will.",
						cite: "Aleister Crowley, introduction to Magick in Theory and Practice (1929)"
					},
					{
						type: "p",
						text: "The k is Crowley's, a mark so you do not confuse the work with stage conjuring. Keep the spelling or drop it. Do not drop the claim. He is not saying you break physics. He is saying a change happens, and it happens in the direction of an intention you can name. A sent message, a refused drink, a cleaned room, a dream you remember: all of those are changes. The techniques in this desk — breath, speech, symbol, ritual sequence — are ways of aiming attention at a change."
					},
					{
						type: "p",
						text: "Whether anything besides attention is involved is not something a definition can settle. Spirit, energy, psychology, and information are models. They tell you where to look and what to record. They are not badges. A serious student can change models without changing the practice log. An unserious one defends a model so hard they stop looking at results."
					},
					{
						type: "h",
						text: "What this desk will not pretend"
					},
					{
						type: "p",
						text: "Oratory is a study room, not a lineage, not an initiator, and not a promise. The rituals here are historical practices written so you can rehearse them with your body and your diary. If a result matters, it has to show up somewhere you can point: sleep, conduct, a finished page, a symptom, a coincidence you logged before you interpreted it. Wonder is allowed. Inflation is how students wreck themselves."
					},
					{
						type: "note",
						tone: "source",
						title: "How to use a lesson",
						text: "Read it once without taking notes. Then write three lines: what it claims, what you disagree with, what you will do before the next meal. Mark it studied only after the three lines exist, even if they live in the diary and not in the margin."
					}
				]
			},
			{
				id: "five-models",
				title: "Five models, one record",
				minutes: 9,
				readingId: "results-and-doubt",
				blocks: [
					{
						type: "p",
						text: "Peter Carroll and the chaos writers did not invent pluralism, but they made it blunt: a model is a tool. Use the one that makes the operation intelligible, and do not marry it. You can hold five without lying."
					},
					{
						type: "steps",
						items: [
							"Spirit. The world is full of persons who are not human. A ritual addresses them. Failure looks like silence, obsession, or a voice that only flatters you. The practice consequence is manners: openings, offerings, and a license to depart.",
							"Energy. The body stores and moves a subtle charge. Failure looks like fried nerves and no sleep. The practice consequence is circulation and banishing, not endless charging.",
							"Psychological. Symbol works on the operator. Failure looks like a mood you mistook for a message. The practice consequence is a diary honest enough to catch the trick.",
							"Information. A ritual is a compressed instruction to attention. Failure looks like vague intent. The practice consequence is a sentence precise enough to falsify.",
							"Meta. You pick a model on purpose, for this working, and you write the choice down. Failure looks like switching stories after the result, so you can never be wrong."
						]
					},
					{
						type: "p",
						text: "Tonight, pick one model and stay inside it for a single exercise. If you are studying the pentagram ritual, spirit is the native model: names, quarters, archangels. If you are making a sigil, information plus psychology will carry you further than a speech about demons. Write the choice at the top of the entry."
					},
					{
						type: "link",
						href: "/theory",
						label: "Open the model table on the theory desk"
					}
				]
			},
			{
				id: "the-record",
				title: "The diary is the practice",
				minutes: 7,
				exerciseId: "evening-record",
				readingId: "magical-diary",
				blocks: [
					{
						type: "p",
						text: "The Golden Dawn required a magical diary. Not as nostalgia. As method. Memory flatters. A page does not, if you write it before you explain it. Students who skip the record do not have a practice. They have a mood they revisit."
					},
					{
						type: "h",
						text: "A minimum entry"
					},
					{
						type: "steps",
						items: [
							"Date, and roughly the hour.",
							"Condition of the body: sleep, food, pain, drink, drugs if any, mood in one plain clause.",
							"What you actually did. Name the exercise. Note the duration. Do not upgrade a thought into a ritual.",
							"What happened during and just after, including boredom, nothing, and the neighbour's dog.",
							"One line the next day, if the result was supposed to show up later."
						]
					},
					{
						type: "p",
						text: "Oratory keeps that record on this device only. It is not an account in the cloud and it will not survive a cleared browser. That is a feature if you write things you would not put in a group chat. It is a risk if this phone is not yours alone. Write accordingly."
					},
					{
						type: "note",
						tone: "caution",
						title: "Do not edit the past into a better story",
						text: "Add a later note. Do not rewrite yesterday so the omen looks cleaner. The second entry is the scholarship. The first entry is the evidence."
					}
				]
			},
			{
				id: "ethics-and-stability",
				title: "Will, other people, and your grip",
				minutes: 8,
				blocks: [
					{
						type: "p",
						text: "Will is not a wish and it is not a weapon you point at someone else's nervous system. The classical work is full of coercive operations. You can study that literature as history. You should not train on living people who have not agreed to be part of your experiment. A statement of intent in this desk is about your conduct, your attention, your body, your work. If the sentence needs someone else to feel, leave, pay, or obey, it is the wrong sentence."
					},
					{
						type: "p",
						text: "The other boundary is your ordinary life. Banishing, breath, and a diary are stabilizing for most students. Visionary practice, sleep loss, fasting, and drugs are not a personality. If practice makes you unable to eat, sleep, tell the difference between a plan and a voice, or keep a promise you made while calm, stop the practice and talk to a person who is paid to care about that — a clinician, not a forum. Magick does not outrank psychosis, and it does not replace medicine."
					},
					{
						type: "note",
						tone: "caution",
						title: "What this desk leaves out on purpose",
						text: "No sex-magick scripts. No pharmacological gnosis. No conjurations copied out for use. Those exist in the books. They are a bad first year, and several of them are a bad tenth year. The work here is attention, symbol, record, and a body that can still pay rent."
					}
				]
			},
			{
				id: "reading-a-grimoire",
				title: "How to read a grimoire",
				minutes: 9,
				readingId: "a-shelf",
				blocks: [
					{
						type: "p",
						text: "A grimoire is a manual of operations, mostly European, mostly late medieval through early modern, often pseudepigraphal — signed with Solomon's name by people who were not Solomon. It is a technical genre. It assumes a Christian cosmos, a kingship model of spirits, and an operator who has already built a life of prayer, purity rules, and tools. Internet summaries keep the threats and drop the container."
					},
					{
						type: "h",
						text: "The parts that matter more than the barbarous names"
					},
					{
						type: "steps",
						items: [
							"Preparation. Time, diet, bath, confession or an equivalent moral inventory, a place set aside.",
							"Tools. Circle, lamens, book, blade, incense. Each one is a job, not a shopping list.",
							"The address. Who is called, by what authority, for what stated purpose.",
							"The constraint. How the operation stays inside a shape.",
							"The license to depart. How it ends. Operations without an ending are how students get haunted by their own attention.",
							"The test. What would count as a result in the world, not in the mood."
						]
					},
					{
						type: "p",
						text: "Your exercise, if you own or can borrow a public-domain text — Agrippa, the Heptameron in an old translation, the Arbatel — is to outline one operation in the diary using those six headings. Do not perform it. Outlining will teach you more than a weekend of improvisation. If you cannot say what the license to depart is, you have not read the ritual. You have read the advertisement."
					}
				]
			}
		]
	},
	{
		id: "hermetic",
		title: "Grammar",
		kicker: "Hermetic scales",
		blurb: "The Tablet, the Kybalion with its real date, the four elements, and the seven planets as a weekly school.",
		lessons: [
			{
				id: "emerald",
				title: "As above, so below",
				minutes: 7,
				readingId: "emerald-tablet",
				blocks: [
					{
						type: "p",
						text: "The Emerald Tablet is a short Arabic Hermetic text, later Latin, centuries older than the occult revival and still not 'ancient Egyptian scripture' in the way parlour lectures claim. Its useful sentence, in the compressed English every student already half-knows, is that what is below corresponds to what is above, and the work of the one thing mediates them."
					},
					{
						type: "p",
						text: "In practice this is a study rule, not a magic wand. A week has seven days and seven classical planets. A body has moods that match a ritual calendar if you bother to notice. A symbol system is a set of rhymes between scales: metal, day, organ, sephirah, tarot trump. You learn the rhymes so a ritual is legible. You do not learn them so you can ignore a thermometer."
					},
					{
						type: "note",
						tone: "source",
						title: "Keep the scales separate at first",
						text: "Golden Dawn quarters are not the same map as many Wiccan ones. Planetary hours are not the same thing as a sun sign. Learn one correspondence set until you can recite it, then read a second. Mixing on day three feels creative and leaves you unable to check your work."
					}
				]
			},
			{
				id: "kybalion-dated",
				title: "The Kybalion, with the date on it",
				minutes: 8,
				readingId: "kybalion",
				blocks: [
					{
						type: "p",
						text: "The Kybalion appeared in 1908, credited to Three Initiates. The voice is William Walker Atkinson, a New Thought writer. It is not a translation of an ancient Hermetic book. That does not make it useless. It makes it a particular modern text with seven principles: Mentalism, Correspondence, Vibration, Polarity, Rhythm, Cause and Effect, Gender. Students who think they are receiving Pharaoh when they are reading Chicago get sloppy about every later source."
					},
					{
						type: "p",
						text: "Read the principles as claims about attention. Mentalism, in Atkinson's hands, slides toward 'everything is mind' in a way that can excuse you from the landlord. Correspondence you already met on the Tablet. Vibration and polarity are ways of talking about degree: fear and courage as a scale, not two substances. Rhythm warns you that a high is not a personality. Cause and effect is the diary. Gender, in that book, is a metaphysical polarity of masculine and feminine principles — do not drag it in as a rule about living people."
					},
					{
						type: "link",
						href: "/library/kybalion",
						label: "Read the longer note on the Kybalion"
					}
				]
			},
			{
				id: "four-elements",
				title: "Four elements as grammar",
				minutes: 7,
				exerciseId: "five-senses",
				blocks: [
					{
						type: "p",
						text: "Earth, water, air, and fire are not a failed chemistry. They are a four-word grammar for states of a working and states of a person. Earth: weight, money, body, the finished object. Water: feeling, dream, dissolution. Air: speech, idea, the breath itself. Fire: will, anger, the strike that starts motion. Most muddled rituals are muddled because the operator wanted fire's result with water's method, or air's talk with no earth at the end."
					},
					{
						type: "p",
						text: "In the Golden Dawn map, which this desk uses unless it says otherwise: east is air, south is fire, west is water, north is earth. Other traditions turn the wheel. If a book does not say which wheel it is using, assume you do not yet know what its pentagram means."
					},
					{
						type: "link",
						href: "/theory",
						label: "Open the quarter map"
					}
				]
			},
			{
				id: "seven-planets",
				title: "Seven planets, seven days",
				minutes: 7,
				exerciseId: "tree-cards",
				readingId: "planetary-week",
				blocks: [{
					type: "p",
					text: "The classical planets in this art are Saturn, Jupiter, Mars, Sun, Venus, Mercury, and Moon. Uranus, Neptune, and Pluto are later grafts. You can learn them. You should not need them to read a 1600s text or a Golden Dawn paper. Each classical planet is a style of action: Saturn restricts, Jupiter expands, Mars cuts, the Sun centers and shows, Venus attracts and adorns, Mercury carries messages and distinctions, the Moon receives and reflects."
				}, {
					type: "p",
					text: "The week is the easiest planetary school there is. Sunday Sun, Monday Moon, Tuesday Mars, Wednesday Mercury, Thursday Jupiter, Friday Venus, Saturday Saturn. Give the day one act in its style, and one line in the diary. That is more useful than a year of collecting correspondences you never enact."
				}]
			}
		]
	},
	{
		id: "tree",
		title: "The Tree",
		kicker: "A filing cabinet",
		blurb: "Ten sephiroth, three pillars, twenty-two paths, and a modest way to walk one path without theatre.",
		lessons: [
			{
				id: "ten-spheres",
				title: "Ten spheres, not a ladder of rank",
				minutes: 8,
				exerciseId: "tree-cards",
				blocks: [
					{
						type: "p",
						text: "The sephiroth come from Jewish mysticism. Hermetic magick borrowed the diagram and loaded it with planets, tarot, and a grade system. You are studying the Hermetic map, and you should know it is a borrowing. Kether, Chokmah, Binah, Chesed, Geburah, Tiphareth, Netzach, Hod, Yesod, Malkuth. Crown, wisdom, understanding, mercy, severity, beauty, victory, splendour, foundation, kingdom."
					},
					{
						type: "p",
						text: "It is not a leaderboard and it is not a mood app. A working that begins in Chokmah's flash and never reaches Malkuth's rent payment has failed in the only sphere that can cash a result. A working that stays in Hod — words about words — has the same problem one floor up from the image-world. Use the tree as a filing cabinet for forces you need to balance, and as a way to notice which room you actually live in."
					},
					{
						type: "link",
						href: "/theory",
						label: "Study the diagram sphere by sphere"
					}
				]
			},
			{
				id: "three-pillars",
				title: "Two pillars and a middle",
				minutes: 6,
				blocks: [{
					type: "p",
					text: "Facing a standard diagram, the right pillar is mercy: Chokmah, Chesed, Netzach. Force, expansion, desire. The left pillar is severity: Binah, Geburah, Hod. Form, boundary, analysis. The middle is mildness: Kether, Tiphareth, Yesod, Malkuth. Students who only read will live in Hod and call it depth. Students who only want will live in Netzach and call it destiny. The middle pillar is the practice of not abandoning either."
				}, {
					type: "p",
					text: "Daath, knowledge, is marked on the middle pillar between Kether and Tiphareth. It is not an eleventh sephirah you attain. In this tradition it names a gap. Treat diagrams that turn the abyss into a content brand with the same suspicion you would give any shortcut."
				}]
			},
			{
				id: "paths-and-tarot",
				title: "Twenty-two paths",
				minutes: 8,
				blocks: [
					{
						type: "p",
						text: "Between the ten spheres the Hermetic tree draws twenty-two paths, numbered 11 to 32, one Hebrew letter each, and in the Golden Dawn one major arcanum each. The Sefer Yetzirah had already split the letters into three mothers, seven doubles, and twelve simples — elements, planets, zodiac. The order of the trumps on the paths is a Golden Dawn decision. It is not the only historical tarot. It is the one you need if you are going to read Mathers, Regardie, Wang, or Crowley without guessing."
					},
					{
						type: "p",
						text: "Crowley swapped the Emperor and the Star, Heh and Tzaddi, under a line in The Book of the Law. The spheres those paths join do not move. If a book looks 'wrong' next to this desk, check whether it is using that swap before you decide the author cannot count."
					},
					{
						type: "note",
						tone: "source",
						title: "One famous path to memorize first",
						text: "Path 13, Gimel, the High Priestess, runs from Kether to Tiphareth. Path 32, Tav, the World, runs from Yesod to Malkuth. If you can place those two, the diagram stops being a poster."
					}
				]
			},
			{
				id: "using-the-map",
				title: "Pathworking without theatre",
				minutes: 7,
				exerciseId: "sit-ten",
				blocks: [{
					type: "p",
					text: "A modest pathworking is a visualized walk from one sphere to a neighbour, using the letter, the tarot image, and a single sensory scene, then a return, then a write-up. It is a concentration exercise with a traditional score. It is not proof you have entered a plane. Treat extraordinary content as dream content: record it, do not obey it the same night, and do not publish it as a revelation before you have slept."
				}, {
					type: "steps",
					items: [
						"Pick one path from the theory desk. Read its two spheres and its card.",
						"Sit for ten minutes. Build one image. Do not force a plot.",
						"Close by feeling the chair, naming the room, and writing ten lines before you speak to anyone.",
						"The next day, mark what was useful and what was costume."
					]
				}]
			}
		]
	},
	{
		id: "ritual",
		title: "Ritual",
		kicker: "A score for attention",
		blurb: "How a working opens and closes, the Qabalistic cross, and the Lesser Banishing Ritual as a form you can memorize.",
		lessons: [
			{
				id: "anatomy",
				title: "Anatomy of a working",
				minutes: 7,
				blocks: [
					{
						type: "p",
						text: "Almost every complete ritual in the Western sets, from a folk charm to a lodge opening, has the same bones. If you can see the bones you can study a new ritual in an evening instead of treating it as a spell to collect."
					},
					{
						type: "steps",
						items: [
							"Open. A purification, a cross, a knock, a breath. You mark that ordinary time has stopped.",
							"Declare. One sentence of intent, said where you can hear it.",
							"Operate. The symbol, the petition, the charge, the middle of the work.",
							"Close. License to depart, banishing, the cross again, the light switched into its ordinary use.",
							"Record. If you skip this, the close did not happen."
						]
					},
					{
						type: "p",
						text: "Improvising is fine once you can feel a missing close in your body. It is a mess if you improvise because you have not learned one complete form. Learn the pentagram ritual as a form before you invent a better one."
					}
				]
			},
			{
				id: "cross-and-names",
				title: "The cross, said properly enough",
				minutes: 8,
				exerciseId: "fourfold-breath",
				blocks: [
					{
						type: "p",
						text: "The Qabalistic cross is the opening and the closing of the Lesser Ritual of the Pentagram. It is also a complete small practice on its own: a way to locate attention in the body along the middle pillar, using words the Golden Dawn inherited from Jewish prayer and rearranged."
					},
					{
						type: "steps",
						items: [
							"Face east. Touch the forehead. Say Ateh — unto thee.",
							"Touch the chest, about the heart or a little below. Say Malkuth — the kingdom.",
							"Touch the right shoulder. Say ve-Geburah — and the power.",
							"Touch the left shoulder. Say ve-Gedulah — and the glory. Gedulah is a name of Chesed, mercy, used here so the line balances severity.",
							"Clasp the hands at the chest. Say le-Olam, amen — unto the ages."
						]
					},
					{
						type: "p",
						text: "Pronunciation varies by teacher. A workable set: Ah-tah. Mahl-koot. Vuh-g'voo-rah. Vuh-g'doo-lah. Luh-oh-lahm. Ah-men. Vibrate means you feel the word in the chest and let it finish, not that you shout the neighbours awake. If you are living with other people, a clear whisper done daily beats a performance you only dare at 2 a.m."
					},
					{
						type: "note",
						tone: "source",
						title: "These names are not neutral souvenirs",
						text: "You are borrowing from a living religion as well as from a Victorian lodge. Study them accurately. Do not mock them, and do not pretend a month of practice makes you a kabbalist in the Jewish sense."
					}
				]
			},
			{
				id: "lbrp-study",
				title: "The Lesser Banishing Ritual, as a score",
				minutes: 12,
				exerciseId: "lbrp-rehearsal",
				diagram: "pentagram",
				readingId: "why-banish",
				blocks: [
					{
						type: "p",
						text: "The Lesser Banishing Ritual of the Pentagram is the Golden Dawn's basic hygiene. Students met it early because it trained stance, breath, memory, and the habit of closing. It is not an exorcism you perform because a room feels spooky on a Tuesday, though the tradition does treat it as a clearing. Learn it as a score you can play from memory. The diagram on this page is the banishing pentagram of earth, the only pentagram the lesser ritual uses."
					},
					{
						type: "h",
						text: "The sequence"
					},
					{
						type: "steps",
						items: [
							"Qabalistic cross, as in the previous lesson.",
							"East. Draw the banishing earth pentagram. Point to its center. Vibrate the Tetragrammaton: Yod, Heh, Vav, Heh. Letter by letter is more honest than a guessed vowel-pointing.",
							"South. The same pentagram. Vibrate Adonai.",
							"West. The same pentagram. Vibrate Eheieh.",
							"North. The same pentagram. Vibrate Agla.",
							"Return to face east. Arms outstretched. Before me Raphael. Behind me Gabriel. At my right hand Michael. At my left hand Auriel. For about me flames the pentagram, and in the column shines the six-rayed star.",
							"Qabalistic cross again.",
							"Stamp the diary with what your attention actually did."
						]
					},
					{
						type: "p",
						text: "Wording shifts between Mathers, Regardie, and later lodges. The skeleton does not: cross, four pentagrams, four names, four archangels, cross. When you can do that skeleton in under ten minutes without a script in your hand, you have begun. Speed is not the point. Independence from the screen is."
					}
				]
			},
			{
				id: "after-the-working",
				title: "Afterward",
				minutes: 6,
				exerciseId: "evening-record",
				readingId: "column-of-attention",
				blocks: [{
					type: "p",
					text: "The ten minutes after a ritual decide whether you integrate it or leak it into argument, scrolling, or a grand theory. Eat something ordinary if you have not eaten. Wash your hands. Write the entry before you interpret it. If you feel raw or grandiose, do the cross once more and go to bed early. Do not add a second, larger ritual to fix the feeling. That is how small practices become all-night spirals."
				}, {
					type: "p",
					text: "A column of attention — breath up the spine, names at crown, throat, heart, groin, and feet, breath down again — is the tradition's other basic hygiene, cousin to what lodges call the Middle Pillar. The essay on the shelf gives you a plain version that is not a copy of any one author's script. Use it when the pentagram ritual leaves you bright and unfocused."
				}]
			}
		]
	},
	{
		id: "chaos",
		title: "Chaos",
		kicker: "Belief, gnosis, sigil",
		blurb: "Spare and the later chaos current: temporary belief, two doors of gnosis, sigils, and servitors with an expiry.",
		lessons: [
			{
				id: "belief-as-tool",
				title: "Belief as a tool",
				minutes: 8,
				blocks: [
					{
						type: "p",
						text: "Chaos magick, as Austin Osman Spare sketched it and Peter Carroll systematized it, says belief is something you can wear for an operation. Not 'nothing is true so nothing matters.' That sentence is an excuse, and it is not what the better books mean. The operational claim is narrower: intense, temporary belief changes what you perceive and what you attempt, and symbol can carry a belief you do not want to hold all week."
					},
					{
						type: "p",
						text: "The discipline is the taking off. If you cannot return to the model you use to cross a street, you are not wielding belief. You are stuck in it. The diary line is simple. Model used. Belief adopted. Time you took it off. What the evening looked like afterward."
					},
					{
						type: "note",
						tone: "caution",
						title: "Paradigm shifting is not a personality disorder you induce for fun",
						text: "If adopted beliefs start lasting through the night, contradicting your memory, or telling you to isolate, stop. The technique has a return ticket or it is not this technique."
					}
				]
			},
			{
				id: "two-doors",
				title: "Two doors into gnosis",
				minutes: 8,
				exerciseId: "fourfold-breath",
				readingId: "two-doors",
				blocks: [
					{
						type: "p",
						text: "Gnosis, in this current, means a brief condition where the ordinary commenting mind goes quiet enough for a signal to be planted or a symbol fired. The classical map has two doors. Inhibitory gnosis empties: stillness, fixation, sensory quiet, the long exhale. Excitatory gnosis overwhelms: spinning, chanting, dancing, gasping breath, music, until the narrator drops."
					},
					{
						type: "p",
						text: "Both doors are physical. Both can be done without drugs and without sex. This desk teaches them that way on purpose. Breath-holds, hyperventilation games, and all-night dancing can still drop you on the floor. Sit down if the room tilts. Pain is not a sign of authenticity. A clean ten-minute silence, reached most days, will do more for your sigils than a monthly collapse."
					},
					{
						type: "steps",
						items: [
							"Inhibitory, this week: the fourfold breath, then two minutes of nothing after it.",
							"Excitatory, next week: a private chant of a single vowel, or a fast walk, until speech feels unnecessary. Then the sigil or the statement, once. Then stop.",
							"Write which door you used. Do not mix them in one evening while you are still learning the difference."
						]
					}
				]
			},
			{
				id: "sigil-method",
				title: "The sigil method",
				minutes: 9,
				exerciseId: "sigil-atelier",
				readingId: "spare-alphabet",
				blocks: [
					{
						type: "p",
						text: "Spare's practical gift was a way to get a desire out of the sentence that keeps arguing with it. You write the intent. You strike the vowels and the repeated letters. You weld what remains into a mark that no longer looks like a request. You charge the mark at a peak or a void. Then you forget the desire on purpose, so you do not pick at it like a scab."
					},
					{
						type: "p",
						text: "Forgetting is the step everyone skips, and it is the step that makes the method different from ordinary worrying. Put the paper away. Do not check hourly whether the sigil is 'working.' Give the result a review date in the diary, a week or a month out, and live as though you had delegated it. If you cannot stop thinking about it, the intent was too hot or too vague. Rewrite it smaller."
					},
					{
						type: "link",
						href: "/practice/sigil-atelier",
						label: "Open the sigil bench"
					}
				]
			},
			{
				id: "servitors",
				title: "Servitors, designed and dismissed",
				minutes: 9,
				readingId: "servitors",
				blocks: [
					{
						type: "p",
						text: "A servitor is a named habit with a job description. In spirit model it is a small constructed entity. In psychological model it is a part you have given a mask so it will actually do the job. Both models can use the same worksheet. The dangers are also the same: a vague job, no expiry, feeding it attention all day, and forgetting you made it."
					},
					{
						type: "steps",
						items: [
							"One function. 'Remind me to leave the desk at ten' is a function. 'Fix my life' is a novel.",
							"A name you will not use in ordinary conversation, and a sign you can draw in two seconds.",
							"A food. Attention is food. Decide the portion: one look at the sign in the morning, nothing else.",
							"A term. Thirty days, then a review.",
							"A kill switch. A sentence that retires it, said once, and the sign destroyed or redrawn as a blank.",
							"No servitor whose job is another person."
						]
					},
					{
						type: "p",
						text: "Build one on paper this month or build none. A crowd of them is how a notebook starts sounding like a board of directors. If you already have a pile of half-intended thoughtforms from older experiments, the practical move is a general license to depart and a fortnight of only the pentagram ritual and the diary. Rest is a technique."
					}
				]
			}
		]
	},
	{
		id: "oratory",
		title: "The hour",
		kicker: "A daily oratory",
		blurb: "How to keep an hour, a spine, a planetary week, and your head when the work is mostly ordinary.",
		lessons: [
			{
				id: "the-hour",
				title: "One hour, most days",
				minutes: 6,
				blocks: [{
					type: "p",
					text: "A study of magick that depends on free weekends will die in the first ordinary month. The hour that survives is boring on paper. Ten minutes of a scored ritual or of breath. Twenty minutes in a book with a pencil. Ten minutes of diary. The rest of the hour is margin so you are not rushed into sloppiness. Five days out of seven beats a heroic Sunday."
				}, {
					type: "p",
					text: "Put the hour where your body already has a hinge: after washing, before the first scroll, or just before cooking. If you live in one room, the oratory can be a chair turned to face the east wall and a cloth you unfold and fold away. Tools help. Dependence on an aesthetic is a stall."
				}]
			},
			{
				id: "breath-and-posture",
				title: "Breath and a spine",
				minutes: 6,
				exerciseId: "fourfold-breath",
				blocks: [{
					type: "p",
					text: "You do not need a yoga credential to sit. Feet on the floor or a stable cushion. Crown imagined as pulled up by a thread, jaw unclenched, hands heavy. The fourfold breath used on this desk is a square: inhale four, hold four, exhale four, hold four. It is old enough, in several cultures, that you do not need a trademarked name for it. If holding the breath makes you panic, drop the holds and keep the even inhale and exhale. Panic is not gnosis."
				}, {
					type: "p",
					text: "Count eight squares as one sitting when you are learning. Then sit two minutes with no count at all. That uncounted tail is where you find out whether you were practicing attention or practicing arithmetic."
				}]
			},
			{
				id: "planetary-day-practice",
				title: "A week with a spine",
				minutes: 7,
				readingId: "planetary-week",
				blocks: [{
					type: "p",
					text: "Use the week as a syllabus so you stop renegotiating your life every morning. The practice page will suggest a matching exercise, but the principle is yours even offline."
				}, {
					type: "steps",
					items: [
						"Sunday, Sun. The cross, or a ten-minute sit. Ask what the center of the week actually is.",
						"Monday, Moon. Dream line in the morning. Yesod work: one image, recorded.",
						"Tuesday, Mars. The pentagram ritual, or a boundary you keep.",
						"Wednesday, Mercury. Flashcards, or three sentences translating a symbol into speech.",
						"Thursday, Jupiter. Read. One real chapter, not a thread.",
						"Friday, Venus. Repair a tool, a page, or a room. Make the oratory slightly more fit to sit in.",
						"Saturday, Saturn. Review the diary. Cut one practice that is only theatre. Plan the next week in seven lines."
					]
				}]
			},
			{
				id: "nothing-happens",
				title: "When nothing happens",
				minutes: 7,
				readingId: "results-and-doubt",
				blocks: [
					{
						type: "p",
						text: "Most sittings are dull. Most sigils are ambiguous. Most pentagram rituals end with a back that hurts and a room that looks the same. This is not a sign you are cut off from a secret world. It is the baseline against which a real oddity can be noticed. Students who need fireworks every time start inventing them. The diary gets more dramatic and the life gets worse."
					},
					{
						type: "p",
						text: "Give any new practice thirty honest sessions before you judge the art. Judge the sessions, meanwhile, on form: did you do the score, did you close, did you write it down. Results get a separate column and a longer clock. If after a month your sleep, temper, and follow-through are worse, the practice is wrong for you or the dose is wrong. Change the dose before you change your cosmology."
					},
					{
						type: "quote",
						text: "Boredom is a result. Write it down with the same pen you would use for a vision."
					}
				]
			}
		]
	}
];
function lessonPath(lessonId) {
	for (const path of paths) {
		const index = path.lessons.findIndex((lesson) => lesson.id === lessonId);
		if (index >= 0) return {
			path,
			lesson: path.lessons[index],
			index
		};
	}
	return null;
}
function lessonCount() {
	return paths.reduce((sum, path) => sum + path.lessons.length, 0);
}
//#endregion
export { lessonPath as n, paths as r, lessonCount as t };
