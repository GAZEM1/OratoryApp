import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route$1, s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title, t as Back } from "./shell-BrWD4Hl0.mjs";
import { r as findExercise } from "./exercises-DXxLx35K.mjs";
import { t as PentagramGuide } from "./pentagram-1vssK5GR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice._exerciseId-CAyoZKmI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var studyCards = [
	{
		id: "kether",
		tag: "Tree",
		front: "Kether",
		back: "Crown. Unity before division. Hermetic attribution: the Primum Mobile, later Neptune."
	},
	{
		id: "chokmah",
		tag: "Tree",
		front: "Chokmah",
		back: "Wisdom. The first outward force. Zodiac, later Uranus. Top of the pillar of mercy."
	},
	{
		id: "binah",
		tag: "Tree",
		front: "Binah",
		back: "Understanding. Form, limit, Saturn. Top of the pillar of severity."
	},
	{
		id: "chesed",
		tag: "Tree",
		front: "Chesed",
		back: "Mercy. Expansion and generosity. Jupiter."
	},
	{
		id: "geburah",
		tag: "Tree",
		front: "Geburah",
		back: "Severity. The power to cut and to hold a boundary. Mars."
	},
	{
		id: "tiphareth",
		tag: "Tree",
		front: "Tiphareth",
		back: "Beauty. The center of the tree, where the pillars are reconciled. The Sun."
	},
	{
		id: "netzach",
		tag: "Tree",
		front: "Netzach",
		back: "Victory. Desire, rhythm, art. Venus."
	},
	{
		id: "hod",
		tag: "Tree",
		front: "Hod",
		back: "Splendour. Language, names, analysis. Mercury."
	},
	{
		id: "yesod",
		tag: "Tree",
		front: "Yesod",
		back: "Foundation. Imagination, dream, the image-body. The Moon."
	},
	{
		id: "malkuth",
		tag: "Tree",
		front: "Malkuth",
		back: "Kingdom. The physical world and the body. Earth. If it does not land here, it is not finished."
	},
	{
		id: "daath",
		tag: "Tree",
		front: "What is Daath?",
		back: "Knowledge. Drawn on the middle pillar between Kether and Tiphareth, but not one of the ten sephiroth. A mark of the abyss, not a place you collect."
	},
	{
		id: "aleph",
		tag: "Paths",
		front: "Path 11, Aleph",
		back: "The Fool. Air. Joins Kether and Chokmah."
	},
	{
		id: "gimel",
		tag: "Paths",
		front: "Path 13, Gimel",
		back: "The High Priestess. Joins Kether and Tiphareth, crossing where Daath is marked."
	},
	{
		id: "tav",
		tag: "Paths",
		front: "Path 32, Tav",
		back: "The World. Joins Yesod and Malkuth. The last step into the kingdom."
	},
	{
		id: "east",
		tag: "Quarters",
		front: "Golden Dawn east",
		back: "Air. The archangel Raphael. You face this way to begin the Lesser Ritual of the Pentagram."
	},
	{
		id: "south",
		tag: "Quarters",
		front: "Golden Dawn south",
		back: "Fire. The archangel Michael. At your right hand when you face east."
	},
	{
		id: "west",
		tag: "Quarters",
		front: "Golden Dawn west",
		back: "Water. The archangel Gabriel. Behind you when you face east."
	},
	{
		id: "north",
		tag: "Quarters",
		front: "Golden Dawn north",
		back: "Earth. The archangel Auriel (Uriel). At your left hand when you face east."
	},
	{
		id: "yHVH",
		tag: "LBRP",
		front: "East, in the LBRP",
		back: "Draw the banishing earth pentagram and vibrate the Tetragrammaton, Yod Heh Vav Heh."
	},
	{
		id: "adonai",
		tag: "LBRP",
		front: "South, in the LBRP",
		back: "Banishing earth pentagram. Divine name: Adonai."
	},
	{
		id: "eheieh",
		tag: "LBRP",
		front: "West, in the LBRP",
		back: "Banishing earth pentagram. Divine name: Eheieh."
	},
	{
		id: "agla",
		tag: "LBRP",
		front: "North, in the LBRP",
		back: "Banishing earth pentagram. Divine name: Agla."
	},
	{
		id: "cross",
		tag: "LBRP",
		front: "Qabalistic cross, the words",
		back: "Forehead Ateh. Chest Malkuth. Right shoulder ve-Geburah. Left shoulder ve-Gedulah. Clasped hands: le-Olam, Amen."
	},
	{
		id: "sigil",
		tag: "Chaos",
		front: "Spare's letter method, in order",
		back: "Write the intent. Remove vowels and repeated letters. Combine what remains into a glyph. Charge it in gnosis. Then let the desire go."
	},
	{
		id: "gnosis",
		tag: "Chaos",
		front: "Two classical doors of gnosis",
		back: "Inhibitory: stillness, silence, trance, the mind emptied. Excitatory: breath, movement, chant, dance, until the ordinary narrator drops. This desk does not use drugs as a door."
	},
	{
		id: "models",
		tag: "Theory",
		front: "Name five models of magick",
		back: "Spirit. Energy. Psychological. Information. Meta — the chaos move of using whichever model does the work, and writing down which one you used."
	},
	{
		id: "will",
		tag: "Theory",
		front: "Crowley's one-sentence definition",
		back: "Magick is the science and art of causing change to occur in conformity with Will. From the introduction to Magick in Theory and Practice."
	},
	{
		id: "kybalion",
		tag: "Sources",
		front: "When was the Kybalion written?",
		back: "1908, by William Walker Atkinson under the mask 'Three Initiates'. It is a New Thought book, not an ancient Egyptian Hermetic text."
	},
	{
		id: "diary",
		tag: "Practice",
		front: "What does a magical diary record first?",
		back: "The date, and the condition of the body: sleep, food, health, mood. Then the practice. Then what actually happened, including nothing."
	}
];
var PHASES = [
	{
		id: "inhale",
		label: "Inhale",
		scale: 1
	},
	{
		id: "hold-in",
		label: "Hold",
		scale: 1
	},
	{
		id: "exhale",
		label: "Exhale",
		scale: .72
	},
	{
		id: "hold-out",
		label: "Hold empty",
		scale: .72
	}
];
function BreathPractice({ onDone }) {
	const [running, setRunning] = (0, import_react.useState)(false);
	const [ticks, setTicks] = (0, import_react.useState)(0);
	const totalRounds = 8;
	const round = Math.floor(ticks / 16);
	const still = round >= totalRounds;
	const phase = PHASES[Math.floor(ticks / 4) % PHASES.length];
	const left = 4 - ticks % 4;
	(0, import_react.useEffect)(() => {
		if (!running || still) return;
		const timer = window.setInterval(() => setTicks((value) => value + 1), 1e3);
		return () => window.clearInterval(timer);
	}, [running, still]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid min-h-72 place-items-center rounded-2xl border border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto grid size-36 place-items-center rounded-full border border-copper bg-raised transition-transform duration-1000",
							style: { transform: `scale(${still ? .86 : phase.scale})` },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-4xl text-copper",
								children: still ? "—" : left
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 font-display text-2xl",
							children: still ? "Uncounted sit" : phase.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: still ? "Two minutes. No count. Then write." : `Round ${Math.min(round + 1, totalRounds)} of ${totalRounds}`
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-3",
				children: still ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StillTail, { onDone }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-full bg-copper px-5 text-copper-ink",
					onClick: () => setRunning((value) => !value),
					children: running ? "Pause" : ticks === 0 ? "Begin" : "Resume"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "If the holds make you panic, stop and breathe evenly instead. Drop the holds. Panic is not the exercise."
			})
		]
	});
}
function StillTail({ onDone }) {
	const [left, setLeft] = (0, import_react.useState)(120);
	const [run, setRun] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!run) return;
		const timer = window.setInterval(() => {
			setLeft((value) => {
				if (value <= 1) {
					setRun(false);
					return 0;
				}
				return value - 1;
			});
		}, 1e3);
		return () => window.clearInterval(timer);
	}, [run]);
	const minute = Math.floor(left / 60);
	const second = String(left % 60).padStart(2, "0");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "flex h-11 items-center text-muted",
		children: left === 0 ? "The tail is done." : `${minute}:${second} of quiet`
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "h-11 rounded-full bg-copper px-5 text-copper-ink",
		onClick: onDone,
		children: "Mark this sit"
	})] });
}
function SitTimer({ onDone }) {
	const [seconds, setSeconds] = (0, import_react.useState)(600);
	const [running, setRunning] = (0, import_react.useState)(false);
	const total = 600;
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const timer = window.setInterval(() => {
			setSeconds((value) => {
				if (value <= 1) {
					setRunning(false);
					chime();
					return 0;
				}
				return value - 1;
			});
		}, 1e3);
		return () => window.clearInterval(timer);
	}, [running]);
	const minute = Math.floor(seconds / 60);
	const second = String(seconds % 60).padStart(2, "0");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl rounded-2xl border border-line bg-surface p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-6xl text-fg",
				children: [
					minute,
					":",
					second
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Ten minutes. Eyes soft. When the tone sounds, write before you talk."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-full bg-copper px-5 text-copper-ink",
					onClick: () => setRunning((value) => !value),
					children: running ? "Pause" : seconds === total ? "Start the sit" : seconds === 0 ? "Sit again" : "Resume"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-full border border-line px-5",
					onClick: onDone,
					children: "Mark practiced"
				})]
			})
		]
	});
}
function chime() {
	try {
		const context = new AudioContext();
		const oscillator = context.createOscillator();
		const gain = context.createGain();
		oscillator.frequency.value = 432;
		oscillator.type = "sine";
		gain.gain.setValueAtTime(1e-4, context.currentTime);
		gain.gain.exponentialRampToValueAtTime(.08, context.currentTime + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, context.currentTime + 1.4);
		oscillator.connect(gain);
		gain.connect(context.destination);
		oscillator.start();
		oscillator.stop(context.currentTime + 1.5);
	} catch {}
}
function StepPractice({ steps, showPentagram, onDone }) {
	const [done, setDone] = (0, import_react.useState)(() => steps.map(() => false));
	const finished = done.every(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			showPentagram ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PentagramGuide, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-3",
				children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": done[index],
					onClick: () => setDone((current) => current.map((value, item) => item === index ? !value : value)),
					className: done[index] ? "w-full rounded-2xl border border-copper bg-raised px-4 py-4 text-left" : "w-full rounded-2xl border border-line bg-surface px-4 py-4 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-copper",
							children: done[index] ? "Done" : index + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl",
							children: step.title
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-muted",
						children: step.detail
					})]
				}) }, step.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: !finished,
				onClick: onDone,
				className: "mt-4 h-11 rounded-full bg-copper px-5 text-copper-ink disabled:opacity-40",
				children: finished ? "Record the rehearsal" : "Mark each station first"
			})
		]
	});
}
function IntentBench() {
	const intent = useDesk((state) => state.intent);
	const setIntent = useDesk((state) => state.setIntent);
	const setSigilStatement = useDesk((state) => state.setSigilStatement);
	const markExercise = useDesk((state) => state.markExercise);
	const checks = (0, import_react.useMemo)(() => assessIntent(intent), [intent]);
	const ready = checks.every((check) => check.ok) && intent.trim().length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "block text-sm text-muted",
				htmlFor: "intent",
				children: "One sentence"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "intent",
				value: intent,
				onChange: (event) => setIntent(event.target.value),
				rows: 4,
				placeholder: "I sleep through the night.",
				className: "mt-2 w-full rounded-2xl border border-line bg-raised px-4 py-3 text-fg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-2",
				children: checks.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: check.ok ? "text-copper" : "text-faint",
						children: check.ok ? "Pass" : "Rework"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: check.label
					})]
				}, check.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !ready,
					onClick: () => markExercise("statement"),
					className: "h-11 rounded-full bg-copper px-5 text-copper-ink disabled:opacity-40",
					children: "Keep this sentence"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/practice/$exerciseId",
					params: { exerciseId: "sigil-atelier" },
					onClick: () => setSigilStatement(intent.trim()),
					className: "inline-flex h-11 items-center rounded-full border border-line px-5",
					children: "Use it on the sigil bench"
				})]
			})
		]
	});
}
function assessIntent(value) {
	const text = value.trim();
	const lower = ` ${text.toLowerCase()} `;
	const other = /\b(he|she|they|him|her|them|his|their)\b/i.test(text) || /\bmake (him|her|them)\b/i.test(lower);
	return [
		{
			ok: text.length > 8,
			label: "Long enough to be a real change, short enough to say aloud."
		},
		{
			ok: (text.match(/[.!?]/g) ?? []).length <= 1,
			label: "One sentence."
		},
		{
			ok: !/\b(not|don't|dont|never|stop|won't|wont|no)\b/i.test(text),
			label: "States the wanted thing. No negation."
		},
		{
			ok: !/\b(try|hope|wish|maybe|should)\b/i.test(text),
			label: "No try, hope, or maybe."
		},
		{
			ok: !/^i will\b/i.test(text),
			label: "Present tense. Not 'I will'."
		},
		{
			ok: !other,
			label: "About your conduct, not someone else's will."
		}
	];
}
function letterPool(statement) {
	const consonants = statement.toUpperCase().replace(/[^A-Z]/g, "").replace(/[AEIOU]/g, "");
	let out = "";
	const seen = /* @__PURE__ */ new Set();
	for (const char of consonants) {
		if (seen.has(char)) continue;
		seen.add(char);
		out += char;
	}
	return out;
}
function SigilBench() {
	const statement = useDesk((state) => state.sigilStatement);
	const setStatement = useDesk((state) => state.setSigilStatement);
	const addSigil = useDesk((state) => state.addSigil);
	const sigils = useDesk((state) => state.sigils);
	const hydrated = useDesk((state) => state.hydrated);
	const removeSigil = useDesk((state) => state.removeSigil);
	const letters = letterPool(statement);
	const canvasRef = (0, import_react.useRef)(null);
	const strokes = (0, import_react.useRef)([]);
	const drawing = (0, import_react.useRef)(null);
	const lettersOn = (0, import_react.useRef)(false);
	const [saved, setSaved] = (0, import_react.useState)(false);
	function resize() {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		canvas.width = Math.max(1, Math.floor(rect.width * dpr));
		canvas.height = Math.max(1, Math.floor(rect.height * dpr));
		redraw();
	}
	(0, import_react.useEffect)(() => {
		resize();
		window.addEventListener("resize", resize);
		return () => window.removeEventListener("resize", resize);
	}, []);
	function point(event) {
		const canvas = canvasRef.current;
		if (!canvas) return {
			x: 0,
			y: 0
		};
		const rect = canvas.getBoundingClientRect();
		return {
			x: (event.clientX - rect.left) / rect.width * canvas.width,
			y: (event.clientY - rect.top) / rect.height * canvas.height
		};
	}
	function redraw() {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		if (lettersOn.current && letters.length > 0) {
			ctx.fillStyle = "#f4eee6";
			ctx.font = `${Math.floor(canvas.width / 14)}px Fraunces, Palatino, serif`;
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			const cx = canvas.width / 2;
			const cy = canvas.height / 2;
			const radius = canvas.width / 5;
			letters.split("").forEach((char, index) => {
				const angle = -Math.PI / 2 + index / letters.length * Math.PI * 2;
				ctx.save();
				ctx.translate(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius);
				ctx.rotate(angle + Math.PI / 2);
				ctx.fillText(char, 0, 0);
				ctx.restore();
			});
		}
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.strokeStyle = "#e08a55";
		ctx.lineWidth = Math.max(3, canvas.width / 140);
		for (const stroke of strokes.current) {
			if (stroke.length < 2) continue;
			ctx.beginPath();
			ctx.moveTo(stroke[0].x, stroke[0].y);
			for (const pt of stroke.slice(1)) ctx.lineTo(pt.x, pt.y);
			ctx.stroke();
		}
	}
	function layLetters() {
		if (letters.length === 0) return;
		lettersOn.current = true;
		redraw();
	}
	function save() {
		const canvas = canvasRef.current;
		if (!canvas || letters.length < 2) return;
		try {
			const image = canvas.toDataURL("image/jpeg", .7);
			addSigil({
				statement: statement.trim(),
				letters,
				image
			});
			setSaved(true);
		} catch {
			setSaved(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "block text-sm text-muted",
				htmlFor: "sigil-statement",
				children: "Statement, then let the letters reduce it"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "sigil-statement",
				value: statement,
				onChange: (event) => {
					setStatement(event.target.value);
					setSaved(false);
				},
				rows: 3,
				className: "mt-2 w-full rounded-2xl border border-line bg-raised px-4 py-3",
				placeholder: "I keep the evening hour."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs tracking-widest text-faint uppercase",
				children: "Letter pool"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-3xl tracking-widest",
				children: letters || "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Vowels gone. Repeats gone. Draw until the letters are no longer a sentence."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "mt-4 h-80 w-full touch-none rounded-2xl border border-line bg-bg",
				onPointerDown: (event) => {
					event.currentTarget.setPointerCapture(event.pointerId);
					drawing.current = [point(event)];
					strokes.current.push(drawing.current);
				},
				onPointerMove: (event) => {
					if (!drawing.current) return;
					drawing.current.push(point(event));
					redraw();
				},
				onPointerUp: () => {
					drawing.current = null;
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-full border border-line px-4",
						onClick: layLetters,
						children: "Lay the letters"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-full border border-line px-4",
						onClick: () => {
							strokes.current.pop();
							resize();
						},
						children: "Undo stroke"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-full border border-line px-4",
						onClick: () => {
							strokes.current = [];
							lettersOn.current = false;
							resize();
						},
						children: "Clear"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: letters.length < 2,
						onClick: save,
						className: "h-11 rounded-full bg-copper px-5 text-copper-ink disabled:opacity-40",
						children: "Put the sigil away"
					})
				]
			}),
			saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Saved on this desk. Do not keep looking at it. Give the result a date in the diary and leave it alone."
			}) : null,
			hydrated && sigils.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3",
				children: sigils.map((sigil) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-surface p-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: sigil.image,
							alt: "Saved sigil",
							className: "aspect-square w-full rounded-xl bg-bg object-contain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 truncate px-1 text-xs text-faint",
							children: sigil.letters
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-1 h-10 px-1 text-sm text-muted",
							onClick: () => removeSigil(sigil.id),
							children: "Dismiss"
						})
					]
				}, sigil.id))
			}) : null
		]
	});
}
function CardDrill({ onDone }) {
	const memories = useDesk((state) => state.cards);
	const gradeCard = useDesk((state) => state.gradeCard);
	const hydrated = useDesk((state) => state.hydrated);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [shown, setShown] = (0, import_react.useState)(false);
	const [seen, setSeen] = (0, import_react.useState)(0);
	const queue = (0, import_react.useMemo)(() => {
		const now = Date.now();
		const due = studyCards.filter((card) => {
			const memory = memories[card.id];
			return !memory || memory.due <= now;
		});
		return due.length > 0 ? due : studyCards;
	}, [memories, hydrated]);
	const card = queue[index % queue.length];
	if (!card) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-faint uppercase",
				children: card.tag
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setShown(true),
				className: "mt-3 min-h-48 w-full rounded-2xl border border-line bg-surface px-5 py-6 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-3xl",
					children: shown ? card.back : card.front
				}), !shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-4 block text-sm text-muted",
					children: "Show the answer"
				}) : null]
			}),
			shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 flex-1 rounded-full border border-line",
					onClick: () => {
						gradeCard(card.id, false);
						setShown(false);
						setIndex((value) => value + 1);
						setSeen((value) => value + 1);
					},
					children: "Again"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 flex-1 rounded-full bg-copper text-copper-ink",
					onClick: () => {
						gradeCard(card.id, true);
						setShown(false);
						setIndex((value) => value + 1);
						const next = seen + 1;
						setSeen(next);
						if (next >= 6) onDone();
					},
					children: "Known"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [hydrated ? `${queue.length} in this pass.` : "Opening the pack.", " Six known cards records the practice."]
			})
		]
	});
}
function PracticeBody({ exercise, onDone }) {
	if (exercise.kind === "breath") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreathPractice, { onDone });
	if (exercise.kind === "timer") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SitTimer, { onDone });
	if (exercise.kind === "steps" && exercise.steps) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepPractice, {
		steps: exercise.steps,
		showPentagram: exercise.id === "lbrp-rehearsal",
		onDone
	});
	if (exercise.kind === "intent") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntentBench, {});
	if (exercise.kind === "sigil") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SigilBench, {});
	if (exercise.kind === "cards") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDrill, { onDone });
	if (exercise.kind === "diary") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/journal",
		className: "inline-flex h-11 items-center rounded-full bg-copper px-5 text-copper-ink",
		children: "Open the diary"
	}) });
	return null;
}
function ExercisePage() {
	const { exerciseId } = Route$1.useParams();
	const exercise = findExercise(exerciseId);
	const markExercise = useDesk((state) => state.markExercise);
	const remember = useDesk((state) => state.remember);
	const [recorded, setRecorded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (exercise) remember("exercise", exercise.id);
	}, [exercise, remember]);
	if (!exercise) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
		href: "/practice",
		label: "All practices"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, { title: "That practice is not on the desk." })] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
			href: "/practice",
			label: "All practices"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: `${exercise.kicker} · ${exercise.minutes} min`,
			title: exercise.title,
			lede: exercise.summary
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PracticeBody, {
			exercise,
			onDone: () => {
				markExercise(exercise.id);
				setRecorded(true);
			}
		}),
		recorded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 max-w-xl text-muted",
			children: [
				"Recorded.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/journal",
					className: "text-copper underline decoration-line underline-offset-4",
					children: "Add a line to the diary"
				}),
				" ",
				"before you explain it to yourself."
			]
		}) : null,
		exercise.lessonId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/lessons/$lessonId",
				params: { lessonId: exercise.lessonId },
				className: "text-sm text-muted underline decoration-line underline-offset-4",
				children: "The lesson behind this practice"
			})
		}) : null
	] });
}
//#endregion
export { ExercisePage as component };
