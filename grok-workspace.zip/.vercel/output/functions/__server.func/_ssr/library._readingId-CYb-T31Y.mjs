import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$5, s as useDesk } from "./router-BSX2fj9N.mjs";
import { n as Shell, r as Title, t as Back } from "./shell-BrWD4Hl0.mjs";
import { t as findReading } from "./library-D_qdTrYh.mjs";
import { t as Blocks } from "./blocks-DL2Q4sMn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library._readingId-CYb-T31Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReadingPage() {
	const { readingId } = Route$5.useParams();
	const reading = findReading(readingId);
	const markReading = useDesk((state) => state.markReading);
	const remember = useDesk((state) => state.remember);
	const done = useDesk((state) => Boolean(state.readings[readingId]));
	const hydrated = useDesk((state) => state.hydrated);
	(0, import_react.useEffect)(() => {
		if (reading) remember("reading", readingId);
	}, [
		reading,
		readingId,
		remember
	]);
	if (!reading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
		href: "/library",
		label: "The shelf"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, { title: "That essay is not on the shelf." })] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
			href: "/library",
			label: "The shelf"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title, {
			kicker: `${reading.shelf} · ${reading.minutes} min`,
			title: reading.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blocks, { blocks: reading.blocks }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex max-w-2xl flex-wrap items-center gap-3 border-t border-line pt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 rounded-full bg-copper px-5 text-copper-ink",
				onClick: () => markReading(reading.id),
				children: hydrated && done ? "Read again" : "Mark as read"
			}), hydrated && done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted",
				children: "On the record."
			}) : null]
		})
	] });
}
//#endregion
export { ReadingPage as component };
