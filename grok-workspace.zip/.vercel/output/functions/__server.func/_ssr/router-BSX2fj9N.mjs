import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BSX2fj9N.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var empty = {
	lessons: {},
	readings: {},
	exercises: {},
	journal: [],
	sigils: [],
	cards: {},
	streak: 0,
	lastDay: null,
	recent: [],
	intent: "",
	sigilStatement: ""
};
function localDay(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function previousDay(date = /* @__PURE__ */ new Date()) {
	const copy = new Date(date);
	copy.setDate(copy.getDate() - 1);
	return localDay(copy);
}
function withDay(state) {
	const today = localDay();
	if (state.lastDay === today) return {
		streak: Math.max(1, state.streak),
		lastDay: today
	};
	return {
		streak: state.lastDay === previousDay() ? state.streak + 1 : 1,
		lastDay: today
	};
}
function rememberList(recent, item) {
	return [item, ...recent.filter((entry) => !(entry.kind === item.kind && entry.id === item.id))].slice(0, 12);
}
function uid() {
	return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}
var useDesk = create()(persist((set) => ({
	...empty,
	hydrated: false,
	setHydrated: (value) => set({ hydrated: value }),
	markLesson: (id) => set((state) => ({
		...withDay(state),
		lessons: {
			...state.lessons,
			[id]: Date.now()
		},
		recent: rememberList(state.recent, {
			kind: "lesson",
			id,
			at: Date.now()
		})
	})),
	markReading: (id) => set((state) => ({
		...withDay(state),
		readings: {
			...state.readings,
			[id]: Date.now()
		},
		recent: rememberList(state.recent, {
			kind: "reading",
			id,
			at: Date.now()
		})
	})),
	markExercise: (id) => set((state) => ({
		...withDay(state),
		exercises: {
			...state.exercises,
			[id]: Date.now()
		},
		recent: rememberList(state.recent, {
			kind: "exercise",
			id,
			at: Date.now()
		})
	})),
	remember: (kind, id) => set((state) => ({ recent: rememberList(state.recent, {
		kind,
		id,
		at: Date.now()
	}) })),
	addJournal: (entry) => set((state) => ({
		...withDay(state),
		journal: [{
			id: uid(),
			at: entry.at ?? Date.now(),
			condition: entry.condition.trim(),
			body: entry.body.trim(),
			practiceId: entry.practiceId
		}, ...state.journal].slice(0, 200)
	})),
	removeJournal: (id) => set((state) => ({ journal: state.journal.filter((entry) => entry.id !== id) })),
	addSigil: (sigil) => set((state) => ({
		...withDay(state),
		exercises: {
			...state.exercises,
			"sigil-atelier": Date.now()
		},
		sigils: [{
			id: uid(),
			at: Date.now(),
			...sigil
		}, ...state.sigils].slice(0, 12),
		recent: rememberList(state.recent, {
			kind: "exercise",
			id: "sigil-atelier",
			at: Date.now()
		})
	})),
	removeSigil: (id) => set((state) => ({ sigils: state.sigils.filter((item) => item.id !== id) })),
	setIntent: (value) => set({ intent: value }),
	setSigilStatement: (value) => set({ sigilStatement: value }),
	gradeCard: (id, known) => set((state) => {
		const current = state.cards[id] ?? {
			box: 0,
			due: 0
		};
		const box = known ? Math.min(5, current.box + 1) : 0;
		const due = known ? Date.now() + box * 864e5 : Date.now() + 6e5;
		return {
			...withDay(state),
			cards: {
				...state.cards,
				[id]: {
					box,
					due
				}
			},
			exercises: {
				...state.exercises,
				"tree-cards": Date.now()
			}
		};
	}),
	clearDesk: () => set({
		...empty,
		hydrated: true
	})
}), {
	name: "oratory-desk",
	skipHydration: true,
	partialize: (state) => ({
		lessons: state.lessons,
		readings: state.readings,
		exercises: state.exercises,
		journal: state.journal,
		sigils: state.sigils,
		cards: state.cards,
		streak: state.streak,
		lastDay: state.lastDay,
		recent: state.recent,
		intent: state.intent,
		sigilStatement: state.sigilStatement
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated(true);
	}
}));
function DeskHydrator() {
	(0, import_react.useEffect)(() => {
		Promise.resolve(useDesk.persist.rehydrate()).finally(() => {
			if (!useDesk.getState().hydrated) useDesk.getState().setHydrated(true);
		});
	}, []);
	return null;
}
var styles_default = "/assets/styles-DKPK4pbM.css";
var APP_NAME = "Oratory";
var FONTS = "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,560;9..144,660&family=Literata:ital,opsz,wght@0,7..72,400;0,7..72,600;1,7..72,400&display=swap";
var Route$14 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "A private desk for studying magick: reading, theory, and practical exercises, kept on this device."
			},
			{
				name: "theme-color",
				content: "#12100e"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: FONTS
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskHydrator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$12 = () => import("./routes-DjP8Zb3J.mjs");
var Route$13 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./journal-DhQOxcdh.mjs");
var Route$12 = createFileRoute("/journal")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./library-IHQSpxsp.mjs");
var Route$11 = createFileRoute("/library")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./paths-BrvCtnja.mjs");
var Route$10 = createFileRoute("/paths")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./practice-BYEY1G3Q.mjs");
var Route$9 = createFileRoute("/practice")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./theory-B3Bwyq5P.mjs");
var Route$8 = createFileRoute("/theory")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./lessons._lessonId-DClmPFg9.mjs");
var Route$7 = createFileRoute("/lessons/$lessonId")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./library.index-BEbABiI9.mjs");
var Route$6 = createFileRoute("/library/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./library._readingId-CYb-T31Y.mjs");
var Route$5 = createFileRoute("/library/$readingId")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./paths.index-bSHurOG1.mjs");
var Route$4 = createFileRoute("/paths/")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./paths._pathId-Dy6WM1G-.mjs");
var Route$3 = createFileRoute("/paths/$pathId")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./practice.index-CZCz6iGf.mjs");
var Route$2 = createFileRoute("/practice/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./practice._exerciseId-CAyoZKmI.mjs");
var Route$1 = createFileRoute("/practice/$exerciseId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var JournalRoute = Route$12.update({
	id: "/journal",
	path: "/journal",
	getParentRoute: () => Route$14
});
var LibraryRoute = Route$11.update({
	id: "/library",
	path: "/library",
	getParentRoute: () => Route$14
});
var PathsRoute = Route$10.update({
	id: "/paths",
	path: "/paths",
	getParentRoute: () => Route$14
});
var PracticeRoute = Route$9.update({
	id: "/practice",
	path: "/practice",
	getParentRoute: () => Route$14
});
var TheoryRoute = Route$8.update({
	id: "/theory",
	path: "/theory",
	getParentRoute: () => Route$14
});
var LessonsLessonIdRoute = Route$7.update({
	id: "/lessons/$lessonId",
	path: "/lessons/$lessonId",
	getParentRoute: () => Route$14
});
var LibraryIndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => LibraryRoute
});
var LibraryReadingIdRoute = Route$5.update({
	id: "/$readingId",
	path: "/$readingId",
	getParentRoute: () => LibraryRoute
});
var PathsIndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => PathsRoute
});
var PathsPathIdRoute = Route$3.update({
	id: "/$pathId",
	path: "/$pathId",
	getParentRoute: () => PathsRoute
});
var PracticeIndexRoute = Route$2.update({
	id: "/",
	path: "/",
	getParentRoute: () => PracticeRoute
});
var PracticeExerciseIdRoute = Route$1.update({
	id: "/$exerciseId",
	path: "/$exerciseId",
	getParentRoute: () => PracticeRoute
});
var LibraryRouteChildren = {
	LibraryReadingIdRoute,
	LibraryIndexRoute
};
var LibraryRouteWithChildren = LibraryRoute._addFileChildren(LibraryRouteChildren);
var PathsRouteChildren = {
	PathsPathIdRoute,
	PathsIndexRoute
};
var PathsRouteWithChildren = PathsRoute._addFileChildren(PathsRouteChildren);
var PracticeRouteChildren = {
	PracticeExerciseIdRoute,
	PracticeIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	JournalRoute,
	LibraryRoute: LibraryRouteWithChildren,
	PathsRoute: PathsRouteWithChildren,
	PracticeRoute: PracticeRoute._addFileChildren(PracticeRouteChildren),
	TheoryRoute,
	LessonsLessonIdRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$7 as a, Route$5 as i, Route$1 as n, localDay as o, Route$3 as r, useDesk as s, router_exports as t };
