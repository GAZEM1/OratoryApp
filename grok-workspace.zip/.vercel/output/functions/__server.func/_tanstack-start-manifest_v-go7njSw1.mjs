//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-go7njSw1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/journal",
			"/library",
			"/paths",
			"/practice",
			"/theory",
			"/lessons/$lessonId"
		],
		preloads: [
			"/assets/index-Cl4Pk246.js",
			"/assets/useSelector-BcTnCC3_.js",
			"/assets/preload-helper-BAl7qJGM.js",
			"/assets/createLucideIcon-DNx5nm_q.js",
			"/assets/root-DLTE-HSj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cl4Pk246.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CS8q_YiH.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/curriculum-CDbsQUzZ.js",
			"/assets/exercises-Gspw6NnM.js",
			"/assets/library-DmINN64U.js"
		]
	},
	"/journal": {
		filePath: "/workspace/src/routes/journal.tsx",
		children: void 0,
		preloads: ["/assets/journal-CKkpqXaA.js", "/assets/shell-zRXEU8s1.js"]
	},
	"/library": {
		filePath: "/workspace/src/routes/library.tsx",
		children: ["/library/$readingId", "/library/"],
		preloads: ["/assets/library-Dv9HgRCs.js"]
	},
	"/paths": {
		filePath: "/workspace/src/routes/paths.tsx",
		children: ["/paths/$pathId", "/paths/"],
		preloads: ["/assets/paths-Dv9HgRCs.js"]
	},
	"/practice": {
		filePath: "/workspace/src/routes/practice.tsx",
		children: ["/practice/$exerciseId", "/practice/"],
		preloads: ["/assets/practice-Dv9HgRCs.js"]
	},
	"/theory": {
		filePath: "/workspace/src/routes/theory.tsx",
		children: void 0,
		preloads: ["/assets/theory-Bya_bhop.js", "/assets/shell-zRXEU8s1.js"]
	},
	"/lessons/$lessonId": {
		filePath: "/workspace/src/routes/lessons.$lessonId.tsx",
		children: void 0,
		preloads: [
			"/assets/lessons._lessonId-CWYm73Hn.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/curriculum-CDbsQUzZ.js",
			"/assets/exercises-Gspw6NnM.js",
			"/assets/library-DmINN64U.js",
			"/assets/blocks-ZsPxKyjE.js",
			"/assets/pentagram-PZv5fp8Y.js"
		]
	},
	"/library/$readingId": {
		filePath: "/workspace/src/routes/library.$readingId.tsx",
		children: void 0,
		preloads: [
			"/assets/library._readingId-DGdC5Z3M.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/library-DmINN64U.js",
			"/assets/blocks-ZsPxKyjE.js"
		]
	},
	"/paths/$pathId": {
		filePath: "/workspace/src/routes/paths.$pathId.tsx",
		children: void 0,
		preloads: [
			"/assets/paths._pathId-DIWZJWZq.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/curriculum-CDbsQUzZ.js"
		]
	},
	"/practice/$exerciseId": {
		filePath: "/workspace/src/routes/practice.$exerciseId.tsx",
		children: void 0,
		preloads: [
			"/assets/practice._exerciseId-BS5z3jXF.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/exercises-Gspw6NnM.js",
			"/assets/pentagram-PZv5fp8Y.js"
		]
	},
	"/library/": {
		filePath: "/workspace/src/routes/library.index.tsx",
		children: void 0,
		preloads: [
			"/assets/library.index-B8zgocp-.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/library-DmINN64U.js"
		]
	},
	"/paths/": {
		filePath: "/workspace/src/routes/paths.index.tsx",
		children: void 0,
		preloads: [
			"/assets/paths.index-DaI7TldP.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/curriculum-CDbsQUzZ.js"
		]
	},
	"/practice/": {
		filePath: "/workspace/src/routes/practice.index.tsx",
		children: void 0,
		preloads: [
			"/assets/practice.index-7MTJfUCJ.js",
			"/assets/shell-zRXEU8s1.js",
			"/assets/exercises-Gspw6NnM.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
